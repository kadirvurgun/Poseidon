// Focused offline closure of exact prior finding using actual App save()/failure/navigation code.
// No React runtime, server, network or DB. Stateful HTTP mock records committed objects/keys.
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import test from 'node:test';import {stripTypeScriptTypes} from 'node:module';
const p=new URL('./',import.meta.url),src=new URL('unpacked/source/src/Frontend/src/',p);
const app=fs.readFileSync(new URL('App.tsx',src),'utf8');
const fragment=app.slice(app.indexOf('  const canLeave = () =>'),app.indexOf('  useEffect(() => {\n    if (!bffEnabled) return;'))+app.slice(app.indexOf('  function navigate('),app.indexOf('  async function open('))+app.slice(app.indexOf('  async function save()'),app.indexOf('  const conflict ='));
const stripped=stripTypeScriptTypes(fragment,{mode:'transform'});
class Failure extends Error{constructor(status,code){super(code);this.status=status;this.code=code;this.errors={};}}
function context(){
 const calls=[],objects=new Map();let keyno=0;const ctx={expired:false,lock:{current:false},kind:'vessels',data:{imo_no:'1234568',notes:'Retained'},lang:'en',pending:null,record:undefined,dirty:true,inventoryDirty:false,inventoryUncertain:false,inventoryView:false,certificateView:false,editor:true,busy:false,bffEnabled:true,sequence:{current:0},vesselSequence:{current:0},vesselAbort:{current:null},listAbort:{current:null},validate:()=>({}),payload:x=>Object.fromEntries(Object.entries(x).filter(([,v])=>v!=='')),normalize:e=>e,newRequestKey:()=>`key-${++keyno}`,t:(_tr,en)=>en,document:{getElementById:()=>null},window:{confirm:message=>{ctx.warning=message;return ctx.allowLeave;}},allowLeave:false,load:()=>{},api:{invalidate:()=>{},save:async(kind,data,key)=>{calls.push({kind,data,key});if(!objects.has(key)){objects.set(key,{draftId:'one',data});throw new Failure(0,'NETWORK_ERROR');}throw new Failure(422,'invalid_imo_checksum');}}};
 for(const k of ['setValidationData','setServerFieldErrors','setBusy','setError','setNotice','setBaseline','setItems','setVessels','setNextCursor','setVesselCursor','setPageCursor','setLoading','setVesselLoading','setInventoryView','setCertificateView','setEditor','setQuery','setFlagFilter','setTypeFilter','setBrowse'])ctx[k]=()=>{};
 ctx.setPending=x=>ctx.pending=typeof x==='function'?x(ctx.pending):x;ctx.setRecord=x=>ctx.record=x;ctx.setData=x=>ctx.data=x;ctx.setExpired=x=>ctx.expired=x;ctx.setKind=x=>ctx.kind=x;
 vm.createContext(ctx);vm.runInContext(stripped+';globalThis.reviewSave=save;globalThis.reviewNavigate=navigate;',ctx);return{ctx,calls,objects};
}
test('Exact old lost-create→new422 repro now preserves key/body and never creates a second object',async()=>{
 const {ctx,calls,objects}=context();await ctx.reviewSave();assert.equal(ctx.pending.uncertain,true);assert.equal(ctx.pending.key,'key-1');ctx.validate=()=>({imo_no:['new rule']});await ctx.reviewSave();assert.equal(ctx.pending.key,'key-1');assert.equal(ctx.pending.uncertain,true);
 ctx.data={imo_no:'',notes:'Retained'};await ctx.reviewSave();assert.deepEqual(calls.map(x=>x.key),['key-1','key-1','key-1']);assert(calls.every(x=>x.data.imo_no==='1234568'));assert.equal(objects.size,1);
});
test('Sticky uncertainty survives later403/409/412/422; same-key reconciliation can finish',async()=>{
 const {ctx,calls,objects}=context();await ctx.reviewSave();const original=ctx.pending;
 for(const status of [403,409,412,422]){ctx.api.save=async(k,d,key)=>{calls.push({data:d,key});throw new Failure(status,'later_rejection');};await ctx.reviewSave();assert.equal(ctx.pending.key,original.key);assert.equal(ctx.pending.data,original.data);assert.equal(ctx.pending.uncertain,true);}
 ctx.api.save=async(k,d,key)=>{calls.push({data:d,key});return objects.get(key);};await ctx.reviewSave();assert.equal(ctx.pending,null);assert.equal(objects.size,1);assert.equal(new Set(calls.map(x=>x.key)).size,1);
});
test('First definitive422 clears pending; new invalid input never starts network write',async()=>{
 const {ctx,calls}=context();ctx.api.save=async()=>{calls.push({});throw new Failure(422,'invalid_imo_checksum');};await ctx.reviewSave();assert.equal(ctx.pending,null);ctx.validate=()=>({imo_no:['bad']});await ctx.reviewSave();assert.equal(calls.length,1);
});
test('Actual401 handler retains uncertainty and expired guard prevents further sends',async()=>{
 const {ctx,calls}=context();ctx.api.save=async()=>{calls.push({});throw new Failure(401,'SESSION_ENDED');};await ctx.reviewSave();assert.equal(ctx.expired,true);assert.equal(ctx.pending.uncertain,true);const pending=ctx.pending;await ctx.reviewSave();assert.equal(calls.length,1);assert.equal(ctx.pending,pending);
});
test('Actual navigation requires explicit uncertainty warning, cancel retains key, accept sends nothing',async()=>{
 const {ctx,calls}=context();await ctx.reviewSave();const original=ctx.pending;ctx.reviewNavigate('certificates');assert.match(ctx.warning,/may already exist/);assert.match(ctx.warning,/original retry key/);assert.equal(ctx.pending,original);assert.equal(ctx.kind,'vessels');assert.equal(calls.length,1);ctx.allowLeave=true;ctx.reviewNavigate('certificates');assert.equal(ctx.pending,null);assert.equal(ctx.kind,'certificates');assert.equal(calls.length,1);
});
test('Actual Record button predicate disables known invalid historical draft and preserves other gates',()=>{
 const inventory=fs.readFileSync(new URL('Inventory.tsx',src),'utf8');const match=inventory.match(/record.adminState==='DRAFT'\?<Button disabled=\{([^}]+)\}/);assert(match);const disabled=Function('parentBusy','busy','expired','dirty','caps','record','return '+match[1]);
 const record={completeness:{missingRequiredFields:[],invalidFields:['imo_no']}};assert.equal(disabled(false,false,false,false,{canManage:true},record),true);record.completeness.invalidFields=[];assert.equal(disabled(false,false,false,false,{canManage:true},record),false);assert.equal(disabled(false,false,false,true,{canManage:true},record),true);
});
