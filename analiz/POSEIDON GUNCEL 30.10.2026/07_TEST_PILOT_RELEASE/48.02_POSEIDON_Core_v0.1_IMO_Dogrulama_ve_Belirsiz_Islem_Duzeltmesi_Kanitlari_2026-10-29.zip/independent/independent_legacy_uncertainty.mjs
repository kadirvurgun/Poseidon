// Offline finding reproduction: actual legacy save() plus actual pre-rollout form validator.
// Mock HTTP simulates committed/lost create, then stricter-server422; no network/DB.
import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';import {stripTypeScriptTypes} from 'node:module';
const p=new URL('./',import.meta.url);
const oldForms=stripTypeScriptTypes(fs.readFileSync(new URL('baseline_verified/src/Frontend/src/forms.ts',p),'utf8'),{mode:'transform'});
const {validate,payload}=await import('data:text/javascript;base64,'+Buffer.from(oldForms).toString('base64'));
const source=fs.readFileSync(new URL('unpacked/source/src/Frontend/src/App.tsx',p),'utf8');const before=fs.readFileSync(new URL('baseline_verified/src/Frontend/src/App.tsx',p),'utf8');assert.equal(source,before,'This legacy UI gap must be identified as pre-existing.');
const save=source.slice(source.indexOf('  async function save()'),source.indexOf('  const conflict ='));
let mode='old',keys=[],stored=new Map(),counter=0;
class Failure extends Error{constructor(status,code){super(code);this.status=status;this.code=code;this.errors={};}}
const ctx={expired:false,lock:{current:false},kind:'vessels',data:{imo_no:'1234568',notes:'Retained'},lang:'en',pending:null,record:undefined,validate,payload,normalize:e=>e,handleFailure:()=>{},newRequestKey:()=>`key-${++counter}`,t:(_tr,en)=>en,document:{getElementById:()=>null},api:{save:async(kind,data,key,record)=>{keys.push(key);if(mode==='old'){stored.set(key,{id:'one',data});throw new Failure(0,'NETWORK_ERROR');}if(data.imo_no==='1234568')throw new Failure(422,'invalid_imo_checksum');stored.set(key,{id:'two',data});return{draftId:'two',data};}}};
for(const k of ['setValidationData','setServerFieldErrors','setBusy','setError','setNotice','setBaseline','setItems','setVessels'])ctx[k]=()=>{};
ctx.setPending=x=>ctx.pending=x;ctx.setRecord=x=>ctx.record=x;ctx.setData=x=>ctx.data=x;
vm.createContext(ctx);vm.runInContext(save+';globalThis.reviewSave=save;',ctx);
await ctx.reviewSave();assert.equal(stored.size,1);assert.equal(ctx.pending.key,'key-1');
mode='new';await ctx.reviewSave();assert.equal(ctx.pending,null);assert.deepEqual(keys,['key-1','key-1']);
ctx.data={imo_no:'',notes:'Retained'};await ctx.reviewSave();assert.deepEqual(keys,['key-1','key-1','key-2']);assert.equal(stored.size,2);
console.log(JSON.stringify({reproduced:true,scope:'PRE_EXISTING_LEGACY_FRONTEND; MOCK_STRICTER_SERVER422; NOT_ACTUAL_UAT',originalKeyDiscardedAfter422:true,manualNextSaveUsesNewKey:true,simulatedObjects:stored.size,noNetworkOrDB:true}));
