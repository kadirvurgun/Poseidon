// Reviewer-owned offline tests of the actual TypeScript modules. No install/network/runtime.
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
import assert from 'node:assert/strict';
import test from 'node:test';
const base=new URL('./unpacked/source/src/Frontend/src/',import.meta.url);
const dataUrl=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
const imoUrl=dataUrl(stripTypeScriptTypes(readFileSync(new URL('imo.ts',base),'utf8'),{mode:'transform'}));
const {imoIssue,imoMessage}=await import(imoUrl);
const formsRaw=stripTypeScriptTypes(readFileSync(new URL('forms.ts',base),'utf8'),{mode:'transform'});
const {validate,payload}=await import(dataUrl(formsRaw.replace('"./imo"',JSON.stringify(imoUrl))));
test('All million six-digit prefixes have exactly one accepted check digit; all10million seven-digit candidates checked',()=>{
 let accepted=0;
 for(let n=0;n<1000000;n++){
  const prefix=String(n).padStart(6,'0');let total=0;let weight=2;for(const digit of [...prefix].reverse())total+=digit.charCodeAt(0)-48? (digit.charCodeAt(0)-48)*weight++ : 0*weight++;
  const expected=total%10;
  for(let last=0;last<10;last++){const issue=imoIssue(prefix+last);assert.equal(issue,last===expected?null:'checksum');if(issue===null)accepted++;}
 }
 assert.equal(accepted,1000000);
});
test('Independent primary-source examples and observed user typo',()=>{
 for(const value of ['1234567','9319466','8814275'])assert.equal(imoIssue(value),null);
 for(const value of ['1234568','8814274'])assert.equal(imoIssue(value),'checksum');
});
test('Exact ASCII length rejects Unicode, whitespace, signs, prefixes, line breaks and embedded controls',()=>{
 for(const value of ['', '123','12345678','１２３４５６７','١٢٣٤٥٦٧','1234567\n','1234567\r',' 1234567','1234567 ','IMO1234567','+1234567','123\x004567','123456\u200b7'])assert.equal(imoIssue(value),'format',JSON.stringify(value));
});
test('Blank optional field omitted; no fabricated or rewritten number',()=>{
 for(const value of ['',undefined]){assert.equal(imoMessage(value,'tr'),null);assert.equal(imoMessage(value,'en'),null);}
 assert.deepEqual(validate('vessels',{imo_no:''},'tr'),{});assert.deepEqual(payload({imo_no:'',notes:'Retained notes'}),{notes:'Retained notes'});
});
test('Both locales and legacy form share exact validator; rejected input/notes are untouched',()=>{
 for(const lang of ['tr','en'])for(const value of ['1234568','１２３４５６７','123']){
  const input={imo_no:value,notes:'Unsaved note'};const before=JSON.stringify(input);const errors=validate('vessels',input,lang);assert.deepEqual(errors.imo_no,[imoMessage(value,lang)]);assert.equal(JSON.stringify(input),before);
 }
 assert.notEqual(imoMessage('1234568','tr'),imoMessage('1234568','en'));
});
test('Checksum arithmetic is not a registry/leading-digit rule',()=>{
 assert.equal(imoIssue('0000000'),null);assert.equal(imoIssue('0000001'),'checksum');assert.equal(imoIssue('9999993'),null);
});
test('Backend algorithm and both write-contract hooks remain exact and company scheme stays separate (static)',()=>{
 const root=new URL('./unpacked/source/src/Backend/',import.meta.url);
 const cs=readFileSync(new URL('ImoNumber.cs',root),'utf8');assert.match(cs,/value.Length == 7 && value.All\(c => c is >= '0' and <= '9'\)/);assert.match(cs,/for \(var i = 0; i < 6; i\+\+\) sum \+= \(value\[i\] - '0'\) \* \(7 - i\)/);assert.match(cs,/sum % 10 == value\[6\] - '0'/);
 const legacy=readFileSync(new URL('Contracts.cs',root),'utf8'),admin=readFileSync(new URL('InventoryContracts.cs',root),'utf8');assert.match(legacy,/if\(p.Name=="imo_no"\) ImoNumber.Validate\(value\)/);assert.match(admin,/if\(p.Name=="imo_no"\) ImoNumber.Validate\(p.Value.GetString\(\)!\)/);assert.match(admin,/p.Name=="company_imo" && !Regex.IsMatch/);assert(!admin.includes('ImoNumber.Validate(value)'));
});
