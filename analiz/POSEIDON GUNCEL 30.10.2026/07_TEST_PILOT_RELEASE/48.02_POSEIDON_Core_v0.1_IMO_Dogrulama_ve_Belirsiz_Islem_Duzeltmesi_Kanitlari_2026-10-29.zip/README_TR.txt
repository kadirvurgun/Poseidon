48.02 IMO doğrulaması ve belirsiz işlem düzeltmesi kanıtları
29 Ekim 2026

Bu wrapper v18 tutulmuş adayı ve v19 düzeltilmiş adayı özgün ZIP baytlarıyla korur. v18 P2 legacy belirsiz işlem anahtarının sonraki 4xx ile kaybı ve P3 geçersiz tarihsel kayıtta Record düğmesi nedeniyle yayımlanmadı. v19 iki bulguyu kapattı ve inceleme kapsamı için CLEAR oldu. Güncel 26.01 kaynağı yalnız v19 ile aynıdır.

v18 bağımsız yedi grup ve 10 milyon yedi-rakam adayının taraması ile ayrı eski belirsizlik reprodüksiyonu korunur. v19 altı odaklı offline kapanış testi ve ikinci statik inceleme vardır. v18 aritmetik kanıtı değişmeyen ilgili dosyalarla taşınır, v19 için yeniden koşulduğu söylenmez. Üretici 226 backend/119 frontend ve iki 6/6 matrisi bağımsız runtime tekrarları değildir; Python bu dilimde yeniden koşulmadı.

Eski açık sekmeler düzeltilmiş bundle değildir. Güncelleme/yenilemeden önce kaydedilmemiş veya sonucu belirsiz işlemler uzlaştırılmalıdır; retry anahtarları sayfa kapanışını aşan kalıcılığa sahip değildir. İptal belleği tutar; bilinçli vazgeçiş sunucudaki olası yazıyı geri almaz.

Checksum yalnız aritmetiktir; sicil tahsisi, IMO uygulanabilirliği veya hukuki geçerlilik değildir. Oturum TTL/auth değişmedi, tarihsel 400/401 nedeni kanıtlanmadı. Kullanıcı IMO düzeltme tekrarını henüz yapmış sayılmaz. Kaynaklardaki üretici NOT_RUN ve no-publication alanları üretici anına aittir; sonraki özel dal yayını 48.01 üst raporunda ayrılır.

Bağımsız betikler geçmiş inceleme kanıtıdır; burada çalıştırılmadı. Kullanıcı ekran görüntüsü, token veya oturum kimliği yoktur.
