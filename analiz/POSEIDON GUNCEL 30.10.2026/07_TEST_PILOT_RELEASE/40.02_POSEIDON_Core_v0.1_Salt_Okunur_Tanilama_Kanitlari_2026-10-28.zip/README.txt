POSEIDON 40.02 Salt okunur tanılama kanıtı

İki özgün üretici ZIP’i byte-for-byte korunur. v7 asıl startup hatasını cleanup hatasının yanında korur. v8 bu düzeltmeyi aynen içerir ve salt-okunur tanılayıcı ekler. İki arşiv de aa51a7d tabanını kullanır; v8 changes.patch kümülatiftir. Güncel 26.01 kaynak ağacı v8 ile aynı 135 dosyadır. v7 ayrı bir nihai kaynak dalı olarak sunulmaz.

v7: 141 girdi ve 140 payload hash’i; üretici 37 test ve dört yerel PG kontrolü. v8: 145 girdi ve 144 payload hash’i; üretici 52 test ve gerçek sentetik PG sınıflandırması. Bağımsız v8 incelemesinde 36 offline test PASS; 15 tanı testi AF_UNIX fixture oluşturma EPERM nedeniyle koşulamadı. Npm kurulum fixture’ı bağımsız koşudan hariçtir. Ürün/browser testleri yeniden koşulmadı. Teknik test sonucu gerçek Codespaces, PID uyuşmazlığı, browser 400 veya UAT çözümü değildir.

Arşivlerin test, yayın ve ortam durumları üretim anını anlatır. Sonraki bağımsız inceleme, kaynak yayını ve gerçek kullanıcı gözlemi 40.01 ile güncel 00.03, 25.02 ve 26.02’de ayrıca kaydedilir. Manifest özgün arşiv bütünlüğünü kontrol eder; kabul belgesi değildir.
