POSEIDON 41.02 Tanılama neden kodu ve peer kimliği kanıtları

Özgün v9 ve v10 üretici ZIP’leri byte-for-byte korunur. v9, f3d689f tabanında sabit başarısız kontrol kodları ekler; 8600bbf olarak yayımlanmıştır. v10, 8600bbf tabanında tanılayıcının farklı PostgreSQL başlangıç fazlarını eşit sayan zaman karşılaştırmasını düzeltir. Güncel 26.01 kaynak v10 ile aynı 135 dosyadır. Her iki arşiv 142 girdi ve 141 payload hash’i içerir.

v9 üretici57; v10 üretici61 testi ayrı toplamlar olarak bildirir, toplanmaz. v10 Linux SO_PEERCRED PID/UID kontrolünü SQL öncesi ve sonrasında kullanır; launcher, auth, ürün ve DB lifecycle kodu değişmemiştir. Salt-okunur tanı düzeltmesi gerçek kullanıcıdaki ilk launcher PID uyuşmazlığının nedenini veya çözümünü kanıtlamaz. MATCH anlık gözlemdir, önceki launcher sahipliği ya da shutdown izni değildir.

Üretici gerçek sentetik PG fixture kanıtı kullanıcı Codespace müdahalesi değildir; yavaş gerçek PostgreSQL startup yeniden üretildi denmez. Bağımsız testlerin koşulan ve ortam nedeniyle koşulmayan kapsamı41.01’de ayrıdır. Ürün/backend/frontend/browser testleri bu dilimde tekrar koşulmadı.

Önceki40.01/40.02 tarihsel kanıtları değiştirilmeden tutulur; zaman eşitliği varsayımının artık geçerli olmadığı güncel41.01 ve üst belgelerde açıklanır. Arşiv içindeki no-publication durumları üretim anını anlatır; sonraki bağımsız inceleme, özel dal yayını ve gerçek kullanıcı gözlemleri üst kontrollü kayıtta ayrılır.
