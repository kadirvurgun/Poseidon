# Karantinalı ek alımı — teknik teslim

Taban `f20a083b2031f988f63862f0dcd5eb6b758e2e15`; 99 taban dosyasının byte eşitliği doğrulandı. Son paket 112 kaynak dosyası içerir. Patch ve SHA-256 manifestleri eklenmiştir. Yerel commit, push, merge veya deployment yapılmadı.

Varsayılan kapalı paylaşılan temel; Vessel/Certificate hedefi, bağımsız evidence:capture ve hedef yönetim yetkisi, metadata rezervasyonu, bounded tek kullanımlık POST akışı, SHA-256/boyut/tür denetimi, karantina, liste/güvenli geçmiş ve gerekçeli yeni dosya sürümü uygular. Eski dosya/hash korunur. BFF CSRF/scope ve tüm işlem boyunca logout kilidi korunur. Gerçek hesap/izin, sağlayıcı, sır veya OS/ağ ayarı oluşturulmadı.

**Doğrulama:** 161 backend (139 eski + 22 yeni), 103 frontend testi PASS; sıfır fail/skip. Locked restore, build (0 uyarı/hata), typecheck PASS. BFF ve legacy TR/EN × 390/768/1440 matrisleri ayrı ayrı 6/6 PASS. BFF sanal HTTPS/TestServer/fake OIDC ile çalıştı; native TLS veya gerçek IdP değildir. BFF matrisi güncel frontend build'iyle tam backend koşusunda geçti. Eski migration sayacı beklentileri yeni migration004'e uyarlandı; yeni liste SQL alias kusuru testle bulundu ve düzeltildi.

**İnceleme düzeltmeleri:** Alım lookup'ı mevcut nesne yetkisini SQL içinde uygular; eksik ve erişilemeyen gemi/sertifika alımlarının status/code/body değerleri detail/history/content için aynıdır. Yerel alımı bırakmak native dosya input'unu da temizler; aynı dosyayı yeniden seçmek otomatik POST başlatmaz. Her iki düzeltme regresyonlarla doğrulandı.

**Kurtarma:** kesilen RECEIVING yüklemesi yeniden yazılmaz; dosya ve kota korunur. Commit sonrası kayıp yanıt durum sorgusuyla çözülür. Otomatik final nesne temizliği ve otomatik kesinti devamı yoktur. Başlangıçta DB/root çift yönlü boyut/hash/kota eşlemesi yapılır. Gerçek disk dolması, elektrik kesintisi veya process kill uygulanmadı; kontrollü hata/iptal noktaları ve yerel kopya/restore sınandı. OS yöneticisine karşı WORM garantisi yoktur.

**Açık kapılar:** scanner yok, tüm baytlar karantinada; download/preview/OCR/AI/export engelli. CLEAN/VERIFIED/EFFECTIVE/READY üretilmez. Gerçek veri sınıflandırması, retention/legal hold/purge, üretim storage/DR/identity/TLS, kontrollü yayın ve insan doğrulama uygulanmadı. Çalışan özel kullanıcı erişimi kurulmadı; Esra UAT PENDING. Bu teslim dört ekranlı modülün veya tam ürünün tamamlandığı anlamına gelmez.

Ayrıntılı sözleşme `source/docs/ADR_EVIDENCE_INTAKE.md`, sentetik kullanıcı adımları `source/docs/EVIDENCE_INTAKE_UAT.md`, makine sonucu `result.json` içindedir. Arşivde screenshot, gerçek dosya, DB, sır, node_modules veya bin/obj yoktur. Ham test logları yerine gerektiği yerde yalnız test adı/sonuç/duration projeksiyonu saklandı.
