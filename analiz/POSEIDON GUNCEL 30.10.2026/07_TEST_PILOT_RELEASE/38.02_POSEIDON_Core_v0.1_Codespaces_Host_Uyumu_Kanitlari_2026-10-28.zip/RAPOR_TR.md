# Codespaces Host uyumluluğu — 28 Ekim 2026

Kaynak tabanı a53135db708a422ee7ff159427f11994f493b41b; yerel commit/push yok.
Dört dosyada dar değişiklik; tam 131 dosyalık kaynak ve baseline patch dahil.

Sahip tanılaması: beklenen dış Host ile loopback GET 200; başarısız tarayıcı
GET günlüğündeki authority tam localhost:8080. Uzak peer veya forwarded başlıklar
gözlemlenmiş sayılmaz. DevelopmentUat, yalnız yapılandırılmış Codespaces origin
ve loopback peer ile bu tam taşıma Host'unu kabul eder; uygulama authority/scheme
sabittir ve doğrulanmış yapılandırmadan gelir. Diğer host/port yazımları reddedilir.
Forwarded başlıklar güven kaynağı değildir. CSRF, dış Origin kontrolü, cookie,
Production reddi, default-off ve private owner-port kontrolleri korunur.

187 backend testi (0 skip), 103 frontend testi, typecheck/build PASS.
İlgili 26 backend testi PASS; gerçek Kestrel'e localhost:8080 Host dönüşümüyle
6 TR/EN viewport akışı PASS. Ayrı sahte OIDC matrisi 6/6 PASS.
Supervisor 30 test tekrar koşusunda PASS; sinyal altkümesi 5/5 PASS.
İlk frontend koşusundaki miras alınan test bayrağı ve supervisor ResourceWarning
kaynaklı stderr testi hatası results.json ve ilk loglarda açıkça kayıtlıdır.
Kod değiştirerek veya uyarıları bastırarak gizlenmedi.

Tarayıcı HTTPS ve yönlendirme emülasyonu gerçek Codespaces retesti değildir.
Chromium --no-sandbox harness, sandbox güvenliğini kanıtlamaz. Gerçek Windows/
Android erişim, native TLS, kullanıcı UAT ve soğuk container başlangıcı PENDING/
NOT_RUN. Docker/NuGet engelli işlemler denenmedi. Kurulu önbellek kullanıldı.
Uygulamanın yerel test süreci durduruldu; kullanıcının runtime'ına dokunulmadı.
Veritabanı dump, payload, ekran görüntüsü, secret, bin/obj/node_modules teslimde yok.

İnceleme ve ayrı yayın sonrası güncelleme adımları source/docs/CODESPACES_UAT_PREPARATION.md
son bölümündedir. Şimdilik kullanıcıya yeniden başlatma/yayın yapılmış denmemeli.
