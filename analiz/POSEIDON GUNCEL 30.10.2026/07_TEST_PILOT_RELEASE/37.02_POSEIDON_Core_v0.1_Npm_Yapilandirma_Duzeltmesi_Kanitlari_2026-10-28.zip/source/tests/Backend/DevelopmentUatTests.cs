using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Xunit;
namespace Poseidon.Tests;
public class DevelopmentUatTests
{
    sealed class Loopback : IStartupFilter {
        public Action<IApplicationBuilder> Configure(Action<IApplicationBuilder> next) => a => {
            a.Use((c,n) => {c.Connection.RemoteIpAddress=IPAddress.Loopback;return n(c);}); next(a);
        };
    }
    sealed class App(string environment="Development", string? invalid=null) : ConfiguredAppFactory {
        readonly string root=MakeRoot();
        static string MakeRoot() { var p=Path.Combine(Path.GetTempPath(),"poseidon-uat-test-"+Guid.NewGuid());Directory.CreateDirectory(p);File.WriteAllText(Path.Combine(p,"index.html"),"synthetic UI");return p; }
        protected override string EnvironmentName=>environment;
        protected override Dictionary<string,string?> Settings { get {
            var s=new Dictionary<string,string?> { ["DevelopmentUat:Enabled"]="true",["DevelopmentUat:Origin"]="https://localhost",["DevelopmentUat:StaticRoot"]=root,["SyntheticIdentity:Enabled"]="false",["Bff:Enabled"]="false",["Database:Initialize"]="false",["EvidenceIntake:Enabled"]="false",["ConnectionStrings:Poseidon"]="Host=unused;Database=unused;Username=unused" };
            if(invalid!=null)s[invalid]=invalid.EndsWith("Enabled")?"true":"https://evil.invalid";return s;
        } }
        protected override IHost CreateHost(IHostBuilder b){b.ConfigureServices(s=>s.AddSingleton<IStartupFilter,Loopback>());return base.CreateHost(b);}
        public HttpClient Client()=>CreateClient(new WebApplicationFactoryClientOptions {BaseAddress=new("https://localhost"),AllowAutoRedirect=false});
        protected override void Dispose(bool disposing){base.Dispose(disposing);if(disposing && Directory.Exists(root))Directory.Delete(root,true);}
    }
    [Theory][InlineData("Production",null)][InlineData("Testing",null)][InlineData("Development","DevelopmentUat:Origin")][InlineData("Development","SyntheticIdentity:Enabled")][InlineData("Development","Bff:Enabled")][InlineData("Development","EvidenceIntake:Enabled")]
    public void Unsafe_runtime_configuration_is_rejected(string environment,string? invalid){using var a=new App(environment,invalid);Assert.Throws<InvalidOperationException>(()=>a.Client());}
    static async Task<string> Csrf(HttpClient c)=>(await c.GetFromJsonAsync<JsonElement>("/bff/antiforgery")).GetProperty("requestToken").GetString()!;
    [Fact] public async Task Development_cookie_login_csrf_scope_logout_and_bearer_separation() {
        using var a=new App();using var c=a.Client();c.DefaultRequestHeaders.Add("Origin","https://localhost");
        Assert.Equal(HttpStatusCode.OK,(await c.GetAsync("/")).StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest,(await c.PostAsync("/bff/login",null)).StatusCode);
        c.DefaultRequestHeaders.Add("X-CSRF-TOKEN",await Csrf(c));
        var login=await c.PostAsync("/bff/login?returnUrl=/",null);Assert.Equal(HttpStatusCode.Redirect,login.StatusCode);
        var cookie=string.Join(";",login.Headers.GetValues("Set-Cookie"));Assert.Contains("__Host-Poseidon.Session",cookie);Assert.Contains("secure",cookie);Assert.Contains("httponly",cookie);Assert.DoesNotContain("uat-manager",cookie);
        var session=await c.GetFromJsonAsync<Session>("/bff/session");Assert.NotNull(session);Assert.True(session!.Synthetic);
        Assert.Equal(HttpStatusCode.Unauthorized,(await c.GetAsync("/api/v1/session")).StatusCode);
        c.DefaultRequestHeaders.Remove("X-CSRF-TOKEN");c.DefaultRequestHeaders.Add("X-CSRF-TOKEN",await Csrf(c));
        Assert.Equal(HttpStatusCode.Conflict,(await c.PostAsync("/bff/login",null)).StatusCode);
        Assert.Equal(HttpStatusCode.Conflict,(await c.PostAsync("/bff/logout",null)).StatusCode);
        c.DefaultRequestHeaders.Add("X-Poseidon-Scope",IdentityBoundary.ScopeStamp(session!));
        Assert.Equal(HttpStatusCode.NoContent,(await c.PostAsync("/bff/logout",null)).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized,(await c.GetAsync("/bff/session")).StatusCode);
    }
    [Fact] public void Framework_key_warmup_uses_only_process_memory() {
        using var a=new App();using var c=a.Client();
        var options=a.Services.GetRequiredService<Microsoft.Extensions.Options.IOptions<Microsoft.AspNetCore.DataProtection.KeyManagement.KeyManagementOptions>>().Value;
        Assert.Equal("DevelopmentKeyRepository",options.XmlRepository!.GetType().Name);
        var provider=a.Services.GetRequiredService<Microsoft.AspNetCore.DataProtection.IDataProtectionProvider>();
        Assert.IsType<Microsoft.AspNetCore.DataProtection.EphemeralDataProtectionProvider>(provider);
    }
    [Fact] public async Task Process_store_expiry_and_revocation_are_enforced() {
        var store=new DevelopmentSessions();
        var identity=new ExternalIdentity(DevelopmentUat.Issuer,"uat-manager");
        var principal=IdentityBoundary.Map(identity,await new DevelopmentGrants().ResolveAsync(identity,default));
        var ticket=new Microsoft.AspNetCore.Authentication.AuthenticationTicket(principal,new Microsoft.AspNetCore.Authentication.AuthenticationProperties {ExpiresUtc=DateTimeOffset.UtcNow.AddMinutes(-1)},BffAuthentication.CookieScheme);
        var key=await store.StoreAsync(ticket);Assert.Null(await store.RetrieveAsync(key));
        ticket.Properties.ExpiresUtc=DateTimeOffset.UtcNow.AddMinutes(20);key=await store.StoreAsync(ticket);Assert.NotNull(await store.RetrieveAsync(key));
        Assert.Null(await new DevelopmentSessions().RetrieveAsync(key));await store.RemoveAsync(key);Assert.Null(await store.RetrieveAsync(key));
    }
    [Fact] public async Task Another_process_infrastructure_rejects_previous_cookie() {
        using var a=new App();using var c=a.Client();c.DefaultRequestHeaders.Add("Origin","https://localhost");c.DefaultRequestHeaders.Add("X-CSRF-TOKEN",await Csrf(c));
        var response=await c.PostAsync("/bff/login",null);var cookie=response.Headers.GetValues("Set-Cookie").Single(x=>x.StartsWith("__Host-Poseidon.Session=")).Split(';')[0];
        using var b=new App();using var other=b.Client();other.DefaultRequestHeaders.Add("Cookie",cookie);Assert.Equal(HttpStatusCode.Unauthorized,(await other.GetAsync("/bff/session")).StatusCode);
    }
    [Theory][InlineData(null)][InlineData("https://evil.invalid")]
    public async Task Missing_or_cross_origin_rejected_before_login(string? origin){using var a=new App();using var c=a.Client();if(origin!=null)c.DefaultRequestHeaders.Add("Origin",origin);c.DefaultRequestHeaders.Add("X-CSRF-TOKEN",await Csrf(c));Assert.Equal(HttpStatusCode.BadRequest,(await c.PostAsync("/bff/login",null)).StatusCode);}
    [Fact] public async Task Forged_forwarded_host_does_not_override_wrong_host(){using var a=new App();using var c=a.Client();c.DefaultRequestHeaders.Host="evil.invalid";c.DefaultRequestHeaders.Add("X-Forwarded-Host","localhost");Assert.Equal(HttpStatusCode.BadRequest,(await c.GetAsync("/")).StatusCode);}
    [Theory][InlineData("//evil.invalid")][InlineData("/bff/session")]
    public async Task Unsafe_return_rejected(string target){using var a=new App();using var c=a.Client();c.DefaultRequestHeaders.Add("Origin","https://localhost");c.DefaultRequestHeaders.Add("X-CSRF-TOKEN",await Csrf(c));Assert.Equal(HttpStatusCode.BadRequest,(await c.PostAsync("/bff/login?returnUrl="+Uri.EscapeDataString(target),null)).StatusCode);}
}
