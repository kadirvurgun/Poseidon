export type Kind = "vessels" | "certificates";
export type DraftData = Record<string, string>;
export interface Session {
  subject: string;
  tenantId: string;
  companyId: string;
  vesselIds: string[];
  synthetic: boolean;
}
export interface Draft {
  draftId: string;
  version: number;
  persistenceState: "DRAFT";
  submissionAllowed: false;
  data: DraftData;
}
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public errors: Record<string, string[]> = {},
  ) {
    super(message);
  }
}
function checkedDraft(value: Draft): Draft {
  if (
    !value ||
    typeof value.draftId !== "string" ||
    !Number.isSafeInteger(value.version) ||
    value.version < 1 ||
    value.persistenceState !== "DRAFT" ||
    value.submissionAllowed !== false ||
    !value.data ||
    typeof value.data !== "object" ||
    Array.isArray(value.data) ||
    Object.values(value.data).some((v) => typeof v !== "string")
  )
    throw new ApiError(
      0,
      "INVALID_RESPONSE",
      "Server response did not confirm a draft.",
    );
  return value;
}
export class Api {
  constructor(
    public token: string,
    private transport: typeof fetch = fetch,
  ) {}
  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    let response: Response;
    try {
      // Native browser fetch must not receive the Api instance as its receiver.
      const transport = this.transport;
      response = await transport(`/api/v1${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          ...(this.token ? { Authorization: `Bearer ${this.token}` } : {}),
          ...init.headers,
        },
      });
    } catch {
      throw new ApiError(
        0,
        "NETWORK_ERROR",
        "The server could not be reached. The save outcome may be unknown.",
      );
    }
    const body = await response.json().catch(() => ({}));
    if (!response.ok)
      throw new ApiError(
        response.status,
        body.code || "HTTP_ERROR",
        body.message || `HTTP ${response.status}`,
        body.errors,
      );
    return body as T;
  }
  session() {
    return this.request<Session>("/session");
  }
  devSession(fixture: string) {
    return this.request<{ accessToken: string; session: Session }>(
      "/dev/session",
      { method: "POST", body: JSON.stringify({ fixture }) },
    );
  }
  async list(kind: Kind) {
    const result = await this.request<{ items: Draft[] }>(`/${kind}`);
    if (!Array.isArray(result.items))
      throw new ApiError(
        0,
        "INVALID_RESPONSE",
        "Server did not return a draft list.",
      );
    return { items: result.items.map(checkedDraft) };
  }
  async get(kind: Kind, id: string) {
    return checkedDraft(
      await this.request<Draft>(`/${kind}/${encodeURIComponent(id)}`),
    );
  }
  async save(kind: Kind, data: DraftData, key: string, record?: Draft) {
    return checkedDraft(
      await this.request<Draft>(
        `/${kind}${record ? `/${encodeURIComponent(record.draftId)}` : ""}`,
        {
          method: "POST",
          headers: {
            "Idempotency-Key": key,
            ...(record ? { "If-Match": `"${record.version}"` } : {}),
          },
          body: JSON.stringify({ saveMode: "DRAFT", data }),
        },
      ),
    );
  }
}
export const newRequestKey = () => crypto.randomUUID();
