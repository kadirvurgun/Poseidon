import { useEffect, useRef, useState } from "react";
import {
  Anchor,
  ArrowLeft,
  Check,
  ChevronRight,
  FileText,
  Globe2,
  LogOut,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  Ship,
  Waves,
} from "lucide-react";
import {
  Api,
  ApiError,
  newRequestKey,
  type Draft,
  type DraftData,
  type Kind,
  type Session,
} from "./api";
import { fields, payload, validate } from "./forms";
import { Button } from "./components/ui/button";
type Lang = "tr" | "en";
export function App() {
  const [lang, setLang] = useState<Lang>("tr");
  const t = (tr: string, en: string) => (lang === "tr" ? tr : en);
  const [api, setApi] = useState<Api | null>(null),
    [session, setSession] = useState<Session | null>(null);
  const [token, setToken] = useState(""),
    [fixture, setFixture] = useState("tenant-a");
  const [kind, setKind] = useState<Kind>("vessels"),
    [items, setItems] = useState<Draft[]>([]),
    [vessels, setVessels] = useState<Draft[]>([]);
  const [editor, setEditor] = useState(false),
    [record, setRecord] = useState<Draft | undefined>(),
    [data, setData] = useState<DraftData>({}),
    [baseline, setBaseline] = useState("{}");
  const [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(false),
    [error, setError] = useState<ApiError | null>(null),
    [serverFieldErrors, setServerFieldErrors] = useState<Record<string, string[]>>({}),
    [notice, setNotice] = useState(""),
    [query, setQuery] = useState("");
  const [pending, setPending] = useState<{
    key: string;
    data: DraftData;
  } | null>(null);
  // Keep the submitted client values, so changing language re-renders the same
  // validation result without changing edits or replacing server diagnostics.
  const [validationData, setValidationData] = useState<DraftData | null>(null);
  const fieldErrors = validationData
    ? validate(kind, validationData, lang)
    : serverFieldErrors;
  const sequence = useRef(0);
  const lock = useRef(false);
  const dirty = JSON.stringify(data) !== baseline;
  const devEnabled = import.meta.env.VITE_ENABLE_DEV_SESSION === "true";
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);
  useEffect(() => {
    const prevent = (event: BeforeUnloadEvent) => {
      if (dirty || pending) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", prevent);
    return () => window.removeEventListener("beforeunload", prevent);
  }, [dirty, pending]);
  const normalize = (e: unknown) =>
    e instanceof ApiError
      ? e
      : new ApiError(
          0,
          "CLIENT_ERROR",
          t("İşlem tamamlanamadı.", "The operation could not be completed."),
        );
  const canLeave = () =>
    (!dirty && !pending) ||
    window.confirm(
      t(
        "Kaydedilmemiş değişiklikler bırakılacak. Devam edilsin mi?",
        "Unsaved changes will be discarded. Continue?",
      ),
    );
  async function connect(dev = false) {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError(null);
    try {
      let client = new Api(token.trim());
      let active: Session;
      if (dev) {
        const result = await client.devSession(fixture);
        client = new Api(result.accessToken);
        active = result.session;
      } else active = await client.session();
      setApi(client);
      setSession(active);
      setToken("");
      setEditor(false);
      setData({});
      setBaseline("{}");
      setPending(null);
    } catch (e) {
      setError(normalize(e));
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  async function load(client: Api, section: Kind) {
    const id = ++sequence.current;
    setItems([]);
    setVessels([]);
    setLoading(true);
    setError(null);
    try {
      const result = await client.list(section);
      const vesselResult =
        section === "vessels" ? result : await client.list("vessels");
      if (id !== sequence.current) return;
      setItems(result.items);
      setVessels(vesselResult.items);
    } catch (e) {
      if (id === sequence.current) setError(normalize(e));
    } finally {
      if (id === sequence.current) setLoading(false);
    }
  }
  useEffect(() => {
    if (api) void load(api, kind);
    return () => {
      sequence.current++;
    };
  }, [api, kind]);
  function navigate(next: Kind) {
    if (busy || (!editor && next === kind) || !canLeave()) return;
    if (next !== kind) sequence.current++;
    if (next !== kind) {
      setItems([]);
      setVessels([]);
    }
    setKind(next);
    setEditor(false);
    setData({});
    setBaseline("{}");
    setPending(null);
    setNotice("");
    setError(null);
    setQuery("");
  }
  async function open(item: Draft) {
    if (!api || busy || !canLeave()) return;
    const id = ++sequence.current;
    setBusy(true);
    setError(null);
    setNotice("");
    try {
      const latest = await api.get(kind, item.draftId);
      if (id !== sequence.current) return;
      setRecord(latest);
      setData(latest.data);
      setBaseline(JSON.stringify(latest.data));
      setEditor(true);
      setServerFieldErrors({});
      setValidationData(null);
      setPending(null);
    } catch (e) {
      setError(normalize(e));
    } finally {
      setBusy(false);
    }
  }
  function create() {
    if (busy || !canLeave()) return;
    const initial: DraftData =
      kind === "vessels" ? { company_id: session!.companyId } : {};
    setRecord(undefined);
    setData(initial);
    setBaseline(JSON.stringify(initial));
    setEditor(true);
    setServerFieldErrors({});
    setValidationData(null);
    setPending(null);
    setError(null);
    setNotice("");
  }
  async function save() {
    if (!api || lock.current) return;
    const errors = validate(kind, data, lang);
    setValidationData(data);
    setServerFieldErrors({});
    if (Object.keys(errors).length) {
      document.getElementById(Object.keys(errors)[0])?.focus();
      return;
    }
    const operation = pending || { key: newRequestKey(), data: payload(data) };
    setPending(operation);
    lock.current = true;
    setBusy(true);
    setError(null);
    setNotice("");
    try {
      const saved = await api.save(kind, operation.data, operation.key, record);
      setRecord(saved);
      setData(saved.data);
      setBaseline(JSON.stringify(saved.data));
      setPending(null);
      setItems((previous) => [
        saved,
        ...previous.filter((i) => i.draftId !== saved.draftId),
      ]);
      if (kind === "vessels")
        setVessels((previous) => [
          saved,
          ...previous.filter((i) => i.draftId !== saved.draftId),
        ]);
      setNotice(t("Taslak sunucuya kaydedildi.", "Draft saved to the server."));
    } catch (e) {
      const failure = normalize(e);
      setError(failure);
      setValidationData(null);
      setServerFieldErrors(failure.errors);
      if (failure.status > 0 && failure.status < 500) setPending(null);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  const conflict = error?.status === 412 || error?.status === 409;
  const authFailed = error?.status === 401 || error?.status === 403;
  function disconnect() {
    if (busy || !canLeave()) return;
    sequence.current++;
    setSession(null);
    setApi(null);
    setItems([]);
    setVessels([]);
    setEditor(false);
    setData({});
    setBaseline("{}");
    setPending(null);
    setError(null);
    setNotice("");
  }
  const errorView = error && (
    <div className="error-panel" role="alert">
      <ShieldAlert size={19} />
      <div>
        <strong>
          {authFailed
            ? t(
                "Oturum veya erişim doğrulanamadı.",
                "Session or access could not be verified.",
              )
            : conflict
              ? t(
                  "Kayıt değişti. Değişikliklerinizi kontrol edin.",
                  "This record has changed. Review your changes.",
                )
              : t("İşlem tamamlanamadı.", "The operation did not complete.")}
        </strong>
        <p>{error.message}</p>
        <small>
          {error.code} {error.status ? `· HTTP ${error.status}` : ""}
        </small>
        {pending && (
          <p>
            {t(
              "Sonuç belirsiz olabilir. Aynı istek kimliğiyle tekrar deneyin; yeni kayıt açmayın.",
              "The outcome may be unknown. Retry with the same request key; do not create another record.",
            )}
          </p>
        )}
        {conflict && record && (
          <Button
            variant="outline"
            onClick={() => void open(record)}
            disabled={busy}
          >
            {t("Sunucudaki sürümü yeniden aç", "Reopen server version")}
          </Button>
        )}
      </div>
    </div>
  );
  return (
    <div className="app-shell">
      <a className="skip-link" href="#main">
        {t("İçeriğe geç", "Skip to content")}
      </a>
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">
            <Anchor size={25} />
          </span>
          <div>
            <strong>POSEIDON</strong>
            <small>{t("Denizcilik çalışma alanı", "Maritime workspace")}</small>
          </div>
        </div>
        <div className="nav-label">{t("ÇALIŞMA ALANI", "WORKSPACE")}</div>
        <nav aria-label={t("Ana menü", "Main navigation")}>
          <button
            className={kind === "vessels" ? "active" : ""}
            onClick={() => navigate("vessels")}
            disabled={!session || busy}
          >
            <Ship size={19} />
            {t("Gemi taslakları", "Vessel drafts")}
            <ChevronRight size={15} />
          </button>
          <button
            className={kind === "certificates" ? "active" : ""}
            onClick={() => navigate("certificates")}
            disabled={!session || busy}
          >
            <FileText size={19} />
            {t("Sertifika taslakları", "Certificate drafts")}
            <ChevronRight size={15} />
          </button>
        </nav>
        <div className="sidebar-note">
          <ShieldAlert size={20} />
          <strong>
            {t("Yalnızca taslak çalışma", "Draft-only workspace")}
          </strong>
          <p>
            {t(
              "Kayıtlar başvuru, hukuki geçerlilik veya operasyonel onay oluşturmaz.",
              "Records do not constitute submission, legal validity or operational approval.",
            )}
          </p>
        </div>
        <div className="sidebar-footer">
          <Waves size={23} />
          <span>
            POSEIDON <small>PRODUCT SLICE · 01</small>
          </span>
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <span className="context">
            {t("Kayıt yönetimi", "Record management")}{" "}
            <ChevronRight size={13} /> <b>{t("Taslak", "Draft")}</b>
          </span>
          <div className="top-actions">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLang(lang === "tr" ? "en" : "tr")}
              aria-label={t("Switch to English", "Türkçeye geç")}
            >
              <Globe2 size={16} />
              {lang === "tr" ? "EN" : "TR"}
            </Button>
            {session && (
              <Button
                variant="outline"
                size="sm"
                onClick={disconnect}
                disabled={busy}
              >
                <LogOut size={15} />
                {t("Çıkış", "Sign out")}
              </Button>
            )}
          </div>
        </header>
        <main id="main" tabIndex={-1}>
          {!session ? (
            <section className="auth-layout">
              <div className="auth-intro">
                <div className="eyebrow">POSEIDON / 01</div>
                <h1>
                  {t(
                    "Filonuzun kayıtları.\nKontrollü bir başlangıç.",
                    "Your fleet records.\nA controlled beginning.",
                  )}
                </h1>
                <p>
                  {t(
                    "Gemi ve sertifika bilgilerini yetkili kapsamınız içinde taslak olarak hazırlayın. Her kayıt açıkça taslak olarak kalır.",
                    "Prepare vessel and certificate information as drafts within your authorized scope. Every record remains explicitly a draft.",
                  )}
                </p>
                <div className="auth-feature">
                  <Ship size={20} />
                  {t("Gemi profilleri", "Vessel profiles")}
                  <span>01</span>
                </div>
                <div className="auth-feature">
                  <FileText size={20} />
                  {t("Sertifika metadata kayıtları", "Certificate metadata")}
                  <span>02</span>
                </div>
              </div>
              <div className="card auth-card">
                <span className="eyebrow">
                  {t("GÜVENLİ ERİŞİM", "SCOPED ACCESS")}
                </span>
                <h2>{t("Oturum doğrulama", "Verify a session")}</h2>
                <p>
                  {t(
                    "Üretim OIDC giriş akışı yapılandırılmalıdır. Bu entegrasyon görünümü, mevcut bir erişim belirtecini sunucuda doğrular.",
                    "Production OIDC sign-in requires configuration. This integration view verifies an existing access token with the server.",
                  )}
                </p>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    void connect();
                  }}
                >
                  <label htmlFor="token">
                    {t("Erişim belirteci", "Access token")}
                  </label>
                  <input
                    id="token"
                    type="password"
                    autoComplete="off"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    required
                    disabled={busy}
                  />
                  <Button type="submit" disabled={busy || !token.trim()}>
                    {busy
                      ? t("Doğrulanıyor…", "Verifying…")
                      : t("Oturumu doğrula", "Verify session")}
                  </Button>
                </form>
                {devEnabled && (
                  <div className="dev-login">
                    <strong>
                      {t(
                        "SENTETİK YEREL GELİŞTİRME",
                        "SYNTHETIC LOCAL DEVELOPMENT",
                      )}
                    </strong>
                    <p>
                      {t(
                        "Gerçek kimlik veya üretim erişimi değildir. Sunucuda ayrıca etkinleştirilmelidir.",
                        "Not a real identity or production access. Must also be explicitly enabled on the server.",
                      )}
                    </p>
                    <label htmlFor="fixture">
                      {t("Test kapsamı", "Test scope")}
                    </label>
                    <select
                      id="fixture"
                      value={fixture}
                      onChange={(e) => setFixture(e.target.value)}
                      disabled={busy}
                    >
                      <option value="tenant-a">Tenant A</option>
                      <option value="tenant-b">Tenant B</option>
                    </select>
                    <Button
                      variant="outline"
                      onClick={() => void connect(true)}
                      disabled={busy}
                    >
                      {t("Sentetik oturum aç", "Open synthetic session")}
                    </Button>
                  </div>
                )}
                {errorView}
                <small className="muted">
                  {t(
                    "Belirteç yalnızca bellekte tutulur; sayfa yenilenince oturum kapanır.",
                    "Token is held in memory only; refreshing ends this session.",
                  )}
                </small>
              </div>
            </section>
          ) : (
            <>
              <div
                className={`session-strip ${session.synthetic ? "synthetic" : ""}`}
              >
                <ShieldAlert size={17} />
                <span>
                  {session.synthetic
                    ? t(
                        "Sentetik yerel oturum · Üretim kimliği değildir",
                        "Synthetic local session · Not a production identity",
                      )
                    : t(
                        "Sunucuda doğrulanmış oturum",
                        "Server-verified session",
                      )}
                </span>
                <span className="session-subject">{session.subject}</span>
              </div>
              <div className="page-heading">
                <div>
                  <div className="eyebrow">
                    {t(
                      "KAYITLAR / TASLAK ÇALIŞMA",
                      "RECORDS / DRAFT WORKSPACE",
                    )}
                  </div>
                  <h1>
                    {kind === "vessels"
                      ? t("Gemi taslakları", "Vessel drafts")
                      : t("Sertifika taslakları", "Certificate drafts")}
                  </h1>
                  <p>
                    {t(
                      "Kaydedin, yeniden açın, bilgileri tamamlayın. Başvuru ve onay bu kapsamın dışındadır.",
                      "Save, reopen and complete information. Submission and approval are outside this scope.",
                    )}
                  </p>
                </div>
                {!editor && (
                  <Button
                    onClick={create}
                    disabled={busy || loading || authFailed}
                  >
                    <Plus size={18} />
                    {t("Yeni taslak", "New draft")}
                  </Button>
                )}
              </div>
              <div className="scope-bar">
                <span>
                  {t("Şirket kapsamı", "Company scope")}
                  <code>{session.companyId}</code>
                </span>
                <span className="draft-badge">
                  {t("Yalnızca TASLAK", "DRAFT only")}
                </span>
              </div>
              {errorView}
              {notice && (
                <div role="status" className="success">
                  <Check size={17} />
                  {notice}
                </div>
              )}
              {editor ? (
                <section className="card editor">
                  <div className="editor-heading">
                    <Button
                      variant="ghost"
                      onClick={() => navigate(kind)}
                      disabled={busy}
                    >
                      <ArrowLeft size={17} />
                      {t("Listeye dön", "Back to list")}
                    </Button>
                    <span className="draft-badge">
                      {t("TASLAK", "DRAFT")}
                      {record ? ` · v${record.version}` : ""}
                    </span>
                  </div>
                  <h2>
                    {record
                      ? t("Taslağı düzenle", "Edit draft")
                      : t("Yeni taslak", "New draft")}
                  </h2>
                  <p className="muted">
                    {t(
                      "Eksik bilgiler taslak olarak kaydedilebilir. Girilen değerler geçerli biçimde olmalıdır.",
                      "Missing metadata can be saved as a draft. Supplied values must have a valid format.",
                    )}
                  </p>
                  {record && <p className="record-id">ID: {record.draftId}</p>}
                  <form
                    noValidate
                    onSubmit={(e) => {
                      e.preventDefault();
                      void save();
                    }}
                  >
                    <div className="form-grid">
                      {fields[kind].map((field) => (
                        <div
                          className={`field ${field.key === "notes" ? "wide" : ""}`}
                          key={field.key}
                        >
                          <label htmlFor={field.key}>
                            {field[lang]}
                            {field.key === "vessel_id" && (
                              <span className="required"> *</span>
                            )}
                          </label>
                          {field.key === "vessel_id" ? (
                            <select
                              id={field.key}
                              value={data[field.key] || ""}
                              disabled={busy || !!pending || !!record}
                              onChange={(e) =>
                                setData({
                                  ...data,
                                  [field.key]: e.target.value,
                                })
                              }
                              aria-required="true"
                              aria-invalid={!!fieldErrors[field.key]}
                              aria-describedby={
                                fieldErrors[field.key]
                                  ? `${field.key}-error`
                                  : undefined
                              }
                            >
                              <option value="">
                                {t(
                                  "Gemi seçin — varsayılan yok",
                                  "Select a vessel — no default",
                                )}
                              </option>
                              {vessels.map((v) => (
                                <option key={v.draftId} value={v.draftId}>
                                  {v.data.name ||
                                    t("Adsız gemi", "Unnamed vessel")}{" "}
                                  · {v.draftId.slice(0, 8)}
                                </option>
                              ))}
                            </select>
                          ) : field.key === "notes" ? (
                            <textarea
                              id={field.key}
                              value={data[field.key] || ""}
                              disabled={busy || !!pending}
                              rows={4}
                              onChange={(e) =>
                                setData({
                                  ...data,
                                  [field.key]: e.target.value,
                                })
                              }
                              aria-invalid={!!fieldErrors[field.key]}
                              aria-describedby={
                                fieldErrors[field.key]
                                  ? `${field.key}-error`
                                  : undefined
                              }
                            />
                          ) : (
                            <input
                              id={field.key}
                              type={field.type || "text"}
                              value={data[field.key] || ""}
                              disabled={busy || !!pending}
                              onChange={(e) =>
                                setData({
                                  ...data,
                                  [field.key]: e.target.value,
                                })
                              }
                              aria-invalid={!!fieldErrors[field.key]}
                              aria-describedby={
                                fieldErrors[field.key]
                                  ? `${field.key}-error`
                                  : undefined
                              }
                              inputMode={
                                field.key === "imo_no" ? "numeric" : undefined
                              }
                            />
                          )}
                          {fieldErrors[field.key] && (
                            <span
                              className="field-error"
                              id={`${field.key}-error`}
                            >
                              {fieldErrors[field.key].join(" ")}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                    <div className="form-footer">
                      <p>
                        {t(
                          "Taslak kaydı ≠ geçerlilik veya uygunluk",
                          "Saving a draft ≠ validity or compliance",
                        )}
                        <small>
                          {t(
                            "Başvuruya izin verilmez.",
                            "Submission is not allowed.",
                          )}
                        </small>
                      </p>
                      <Button
                        type="submit"
                        disabled={busy || conflict || authFailed}
                      >
                        {busy
                          ? t("Kaydediliyor…", "Saving…")
                          : pending
                            ? t("Aynı isteği tekrar dene", "Retry same request")
                            : t("Taslağı kaydet", "Save draft")}
                      </Button>
                    </div>
                  </form>
                </section>
              ) : (
                <section className="card list-card">
                  <div className="list-toolbar">
                    <label className="search">
                      <Search size={18} />
                      <span className="sr-only">
                        {t("Taslaklarda ara", "Search drafts")}
                      </span>
                      <input
                        placeholder={t(
                          "Ad veya numara ile ara…",
                          "Search by name or number…",
                        )}
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                      />
                    </label>
                    <Button
                      variant="ghost"
                      onClick={() => api && void load(api, kind)}
                      disabled={loading || busy}
                    >
                      <RefreshCw size={16} />
                      {t("Yenile", "Refresh")}
                    </Button>
                  </div>
                  {loading ? (
                    <div role="status" className="empty">
                      {t("Sunucudan yükleniyor…", "Loading from server…")}
                    </div>
                  ) : error ? (
                    <div className="empty">
                      {t(
                        "Kayıtlar yüklenemedi. Listeyi yenileyin veya oturumunuzu doğrulayın.",
                        "Records could not be loaded. Refresh the list or verify your session.",
                      )}
                    </div>
                  ) : items.length === 0 ? (
                    <div className="empty">
                      <div className="empty-icon">
                        {kind === "vessels" ? (
                          <Ship size={30} />
                        ) : (
                          <FileText size={30} />
                        )}
                      </div>
                      <h2>{t("Henüz taslak yok", "No drafts yet")}</h2>
                      <p>
                        {t(
                          "Bu kapsamda yeni bir taslak oluşturarak başlayın.",
                          "Start by creating a draft in this scope.",
                        )}
                      </p>
                    </div>
                  ) : (
                    <div className="table-wrap">
                      <table>
                        <thead>
                          <tr>
                            <th>
                              {kind === "vessels"
                                ? t("Gemi / numara", "Vessel / number")
                                : t(
                                    "Sertifika / numara",
                                    "Certificate / number",
                                  )}
                            </th>
                            <th>{t("Durum", "State")}</th>
                            <th>{t("Sürüm", "Version")}</th>
                            <th>
                              <span className="sr-only">
                                {t("İşlem", "Action")}
                              </span>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {items
                            .filter((i) =>
                              Object.values(i.data)
                                .join(" ")
                                .toLocaleLowerCase(lang)
                                .includes(query.toLocaleLowerCase(lang)),
                            )
                            .map((item) => (
                              <tr key={item.draftId}>
                                <td>
                                  <strong>
                                    {item.data.name ||
                                      item.data.type ||
                                      t("Adsız taslak", "Untitled draft")}
                                  </strong>
                                  <small>
                                    {item.data.imo_no ||
                                      item.data.certificate_no ||
                                      item.draftId}
                                  </small>
                                </td>
                                <td>
                                  <span className="draft-badge">
                                    {t("TASLAK", "DRAFT")}
                                  </span>
                                </td>
                                <td className="muted">v{item.version}</td>
                                <td>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onFocus={(event) =>
                                      event.currentTarget.scrollIntoView({
                                        block: "nearest",
                                        inline: "nearest",
                                      })
                                    }
                                    onClick={() => void open(item)}
                                    disabled={busy}
                                  >
                                    {t("Aç", "Open")}
                                    <ChevronRight size={16} />
                                  </Button>
                                </td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                      {items.filter((i) =>
                        Object.values(i.data)
                          .join(" ")
                          .toLocaleLowerCase(lang)
                          .includes(query.toLocaleLowerCase(lang)),
                      ).length === 0 && (
                        <div className="empty">
                          {t(
                            "Aramanızla eşleşen taslak yok.",
                            "No matching drafts.",
                          )}
                        </div>
                      )}
                    </div>
                  )}
                  <div className="list-footer">
                    {items.length}{" "}
                    {t(
                      "sunucu kaydı · yalnızca yetkili kapsam",
                      "server records · authorized scope only",
                    )}
                  </div>
                </section>
              )}
              <footer className="main-footer">
                <span>POSEIDON</span>
                {t(
                  "Taslak kayıt alanı · Başvuru, onay veya operasyon izni içermez.",
                  "Draft workspace · No submission, approval or operational authorization.",
                )}
              </footer>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
