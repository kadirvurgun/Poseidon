# Poseidon yerel uçtan uca doğrulama — 27 Ekim 2026

Sonuç: **yerel düzeltmeyle PASS**. Orijinal commit gerçek tarayıcıda girişte başarısızdı; düzeltme commit/push edilmedi.

- Depo: emgt41/Poseidon. HEAD: `fc4c9858205a02c8ba3d41b5495d525a73bb4a69`. Gerçek yerel dal `work`; yerel `origin/main` aynı SHA. Başlangıç çalışma ağacı temizdi; kullanıcı değişikliği yoktu. Uzak dalın güncelliği fetch ile kontrol edilmedi.
- Kurulu araçlar yeniden kullanıldı: .NET SDK 10.0.403 / runtime 10.0.14, PostgreSQL 17.11, Node 24.19.0, Chromium 154.0.8037.57, Playwright 1.62.1. Node, önceki belgedeki 24.22.1 değildir.
- Mevcut install.sh ve env ayarları kullanıldı; yeniden kurulum yapılmadı. Başlangıçta servisler çalışmıyordu; mevcut PostgreSQL kümesi özel Unix soketinde, API 127.0.0.1:5080 ve Vite 127.0.0.1:5173 üzerinde başlatıldı. İnternet yayını yok.

| Kontrol | İlk durum | Düzeltme sonrası |
|---|---|---|
| Gerçek PostgreSQL backend testleri | PASS 37, FAIL 0, SKIP 0 | PASS 37, FAIL 0, SKIP 0 |
| Frontend birim testleri | PASS 32 | PASS 33 |
| Typecheck / build | PASS / PASS | PASS / PASS |
| Gerçek tarayıcı girişi | FAIL: Illegal invocation | PASS |
| git diff --check | — | PASS |

Backend testleri gerçek `poseidon_test` veritabanında koştu; güvenli test adı kontrolü değiştirilmedi. Frontend birim testleri HTTP taklitleri kullanır; aşağıdaki tarayıcı sonuçları ise gerçek API ve PostgreSQL bağlantılıdır.

**Bulunan kusur ve yerel düzeltme:** `Api.request` içindeki `this.transport(...)`, yerleşik tarayıcı fetch fonksiyonuna Api nesnesini alıcı olarak geçiriyordu. Chromium `Failed to execute 'fetch' on 'Window': Illegal invocation` üretti; UI bunu NETWORK_ERROR olarak gösterdi. Transport yerel değişkene alınıp bağımsız fonksiyon olarak çağrıldı. Regresyon testi eklendi. Patch yalnız iki frontend dosyasını değiştirir; yetki/veri modeli değişmez.

**Gerçek Chromium kapsamı (12 kontrol grubu PASS):** açık sentetik A girişi; eksik alanlarla gemi taslağı; sunucudan yeniden açma ve v2 güncelleme; TR/EN iki yönlü geçiş; hatalı IMO için alan hatası ve sıfır yazma isteği; gerçek HTTP 422/401/403 reddi; ikinci gerçek yazar sonrası UI'da 412 ve kaydetmenin engellenmesi, açık yeniden yükleme; gerçek sunucu commit'inden sonra yanıtın kontrollü düşürülmesi ve aynı anahtar/payload/If-Match ile tekrar sonucunun aynı v4 olması; gemiye bağlı eksik sertifika ve geçersiz tarih aralığının engellenmesi; B ekranında A gemisinin görünmemesi ve A gemi/sertifika GET için 404; tarayıcı yenilemesi sonrası yeni A oturumuyla kalıcılık; API SIGTERM/restart sonrası yeni tarayıcıda gemi v4 ve sertifikanın yeniden açılması.

Belirsiz yanıt deneyi gerçek sunucu yazısını yaptıktan sonra yalnız cevabı Playwright ile düşürdü; sahte başarı cevabı veya mock API kullanılmadı. Bu kontrollü hata enjeksiyonudur, gerçek altyapı kesintisi kanıtı değildir. UI testleri headless Chromium etkileşimidir; tam görsel, erişilebilirlik veya çoklu tarayıcı kabulü değildir.

**NOT_RUN:** üretim OIDC, üretim dağıtımı/HTTPS, operasyonel-denizcilik onayları, veritabanı/host yeniden başlatma ve yedekten dönüş, uzun süreli dayanıklılık, tam manuel görsel/erişilebilirlik/mobil inceleme. **SKIP: 0 backend testi. Kalan erişim/servis engeli: yok.**

README, global.json, DEPLOYMENT_TARGET, DEVELOPMENT_DECISIONS ve backend/frontend README'leri okundu. Mevcut belgelerdeki eski entegrasyon engeli ifadeleri değiştirilmedi; bu rapor yalnız gerçekten doğrulanan geliştirme kapsamı için yeni kanıttır. Müşteri verisi, kalıcı hesap/anahtar, izin değişikliği, push, merge veya deployment oluşturulmadı. Sentetik taslaklar mevcut geliştirme veritabanında kaldı.

Komutlar, ayrıntılı PASS/FAIL/NOT_RUN ve sürümler `result.json` içindedir. Tekrar kullanılabilir tarayıcı scriptleri, test günlükleri/TRX ve `fetch-receiver.patch` ektedir. Scriptler mevcut yerel yolları varsayar; başka ortamda yollar uyarlanmalıdır. Sır, ortam dosyası, gerçek veritabanı, node_modules veya ekran görüntüsü dahil değildir.
