import pathlib,os,json,importlib.util,subprocess,signal,threading,time
from unittest.mock import patch
root=pathlib.Path('/workspace/Poseidon-readiness-timeout');old=pathlib.Path('/workspace/Poseidon-startup-cause-fix');state=pathlib.Path('/workspace/poseidon-diag-xy2uffmp/.poseidon-synthetic-uat');data=state/'pgdata';sock=state/'socket'
assert json.loads((state/'owner.json').read_text())=={'purpose':'poseidon-synthetic-uat-v1','repository':str(old)}
spec=importlib.util.spec_from_file_location('readiness_fixture',root/'scripts/uat.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOT=old
env=m.clean_env(os.environ);env['LD_LIBRARY_PATH']=os.environ.get('LD_LIBRARY_PATH','')
c=m.OwnedPostgres(data,sock,state,env);old_timed_out=False;calls=0;resume=None
real_run=subprocess.run
try:
 c.start();assert (data/'postmaster.pid').read_text().splitlines()[0]==str(c.process.pid)
 c.process.send_signal(signal.SIGSTOP)
 try:
  try:real_run(['pg_isready','-q','-h',str(sock),'-p','55433'],env=env,timeout=2)
  except subprocess.TimeoutExpired:old_timed_out=True
 finally:c.process.send_signal(signal.SIGCONT)
 assert old_timed_out;c.wait_ready()
 c.process.send_signal(signal.SIGSTOP)
 def resume_owned():
  if c.process.poll() is None:c.process.send_signal(signal.SIGCONT)
 resume=threading.Timer(2.8,resume_owned);resume.start()
 def tracked(cmd,**kwargs):
  global calls
  if cmd[0]=='pg_isready':calls+=1
  return real_run(cmd,**kwargs)
 begin=time.monotonic()
 with patch.object(m.subprocess,'run',side_effect=tracked):c.wait_ready()
 elapsed=time.monotonic()-begin;resume.join();assert calls>=2;assert elapsed<30
 c.close();assert not (data/'postmaster.pid').exists()
 print(json.dumps({'oldOuterTwoSecondTimeoutReproduced':old_timed_out,'newBoundedRetryPassed':True,'actualProbeCalls':calls,'withinThirtySecondDeadline':elapsed<30,'ownedChildPidMatchedBeforeAndAfter':True,'allOwnedChildrenStopped':True,'newDatabaseCreated':False,'userCodespaceTouched':False,'limitation':'Task-owned stopped/resumed postmaster models delayed readiness; actual Codespaces cold-start/PID mismatch not reproduced'},indent=2))
finally:
 if resume:resume.cancel();resume.join()
 if c.process and c.process.poll() is None:c.process.send_signal(signal.SIGCONT)
 c.close()
