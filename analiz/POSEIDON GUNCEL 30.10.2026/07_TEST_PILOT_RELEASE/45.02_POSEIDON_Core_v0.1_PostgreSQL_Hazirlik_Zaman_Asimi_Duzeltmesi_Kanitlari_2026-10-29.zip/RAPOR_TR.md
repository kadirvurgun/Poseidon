# PostgreSQL readiness timeout düzeltmesi

Taban a27cb4fd8df3bf3d0072b130aea4f47c1ee50f81. Kaynak ve resmî PG17 belgesi
varsayılan pg_isready3s / dıştimeout2s uyumsuzluğunu doğruladı. Tek geçici probe
timeout'u başlangıcı hemen iptal ediyordu. Ready kontrolü explicit -t1, dış<=2s,
toplam30s monotonic deadline ile bounded retry kullanır. Sadece aynı izlenen child
PID'sinin ready yanıtı kabul edilir; başka server adoption yok.

86 test PASS. Gerçek mevcut task-owned PG fixture'ı SIGSTOP/SIGCONT ile gecikince
eski timeout tekrar üretildi; yeni akış3 probe içinde hazır oldu. Child PID
başta/sonda eşleşti; temiz stop yapıldı, yeni DB oluşturulmadı. Fixture ROOT test
modülünde önceki sahibiyle eşlendi; marker değişmedi. Bu actual Codespaces
cold-start/PID mismatch reprodüksiyonu değildir. Tarihsel mismatch nedeni UNKNOWN.

Cleanup güvenlik reddi ve supervisor lock/retained child signal davranışı aynen
korundu. User Codespace'e hiçbir işlem yok, tekrar launcher/stop talimatı yok.
İnceleme sonrası mevcut running DB için ayrı fresh identity/recovery yolu gerekir.
No push/commit/deploy/credentials/security change. 141 kaynak ve baseline patch,
hash/evidence dahil; ürün backend/frontend/browser NOT_RERUN.
