using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
namespace Poseidon.Tests;
public class ConfiguredAppFactory:WebApplicationFactory<Program> {
 protected virtual string EnvironmentName=>"Development";
 protected virtual Dictionary<string,string?> Settings=>new(){["SyntheticIdentity:Enabled"]="true",["Database:Initialize"]="false",["ConnectionStrings:Poseidon"]="Host=unused;Database=unused;Username=unused"};
 protected override IHost CreateHost(IHostBuilder builder){builder.UseEnvironment(EnvironmentName);builder.ConfigureHostConfiguration(c=>c.AddInMemoryCollection(Settings));return base.CreateHost(builder);}
}
