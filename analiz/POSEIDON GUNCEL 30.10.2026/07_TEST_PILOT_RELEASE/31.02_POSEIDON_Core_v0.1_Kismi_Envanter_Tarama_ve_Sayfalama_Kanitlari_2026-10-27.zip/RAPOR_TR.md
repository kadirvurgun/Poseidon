# Poseidon — kısmi envanter tarama teslimi

Taban/HEAD: d0640b270c81f1db4e190c6f1c090794e08f51ab. Yayımlanan 62 dosya önce yerel
kaynakla byte düzeyinde doğrulandı; çalışma ağacı korunarak tabana hizalandı. Yeni
commit/push/merge/deployment, gerçek hesap/IdP veya güvenlik ayarı yoktur.

Bu dilim tam Envanter modülü değildir. Esra'nın kullanıcı kabulü BEKLİYOR.
Uygulanan: kapsam denetimli q/flag/vessel_type sorgusu, 50 varsayılan/100 maksimum
UUID keyset sayfalama, sorgu/kapsam bağlı cursor, items/nextCursor/hasMore cevabı;
UI server araması/filtre sıfırlama/ilk-sonraki sayfa, sertifika için bağımsız server
gemi araması ve daha fazla yükleme, abort + sıra numarasıyla eski yanıt koruması.
Seçili gemi yeni arama sonucunda yoksa seçim korunur; varsayılan seçim üretilmez.

Kanonik karşılaştırma: kaynak yalnız cursor/stable sort ve items/nextCursor belirtir.
Yeni q/filter/pageSize/hasMore semantiği ADR INVENTORY-001 uygulama kararıdır, önceki
kanonik onay gibi sunulmaz. Taslak alanları, optional IMO, eksik metadata kabulü,
replacement/If-Match/idempotency/audit ve mevcut auth sınırları korunur. History-read,
raw actor projection, şirket çapında yeni görünürlük, aktivasyon/silme/status enum'u
ve sertifika geçerlilik kararı eklenmedi.

Son kanıtlar:
- Backend 103 PASS, 0 FAIL, 0 SKIP (önceki 92 + yeni 11).
- Frontend 53 PASS, 0 FAIL, 0 SKIP (önceki 47 + yeni 6).
- Locked restore, backend build, frontend typecheck ve default/BFF build PASS;
  backend 0 uyarı/0 hata.
- Mevcut 390/768/1440 × TR/EN responsive matrisi 6/6 PASS, taslak POST 0.
- Gerçek Chromium BFF TR/EN akışı PASS; sertifika seçimi yeni server gemi aramasını
  kullanır. ASP.NET handler + PostgreSQL gerçektir; IdP process-only fixture ve
  HTTPS/redirect Playwright-TestServer relay'dir, gerçek sağlayıcı/TLS kanıtı değildir.
- Yeni PostgreSQL testi 626 yetkili kaydı sayfalar; değişmeyen kümede 626 benzersiz
  sonuç, foreign tenant/company/owner dışlanması, explicit grant, literal wildcard,
  ASCII locale, input/cursor sınırları, insert/update sayfa tutarlılığı sınırlarını sınar.
- Frontend fixture'ı 625 kaydı temsil eder; ilk sayfa/500 ötesindeki 550/625. kaydın
  sertifika seçimi, arama sonrası seçimin korunması, dirty cancel, geç yanıt ve session
  invalidation senaryolarını sınar. Bu 625-record UI testi jsdom/mock transport'tur;
  gerçek PostgreSQL toplu sorgu testi ayrı kanıttır.

İlk testte durmuş mevcut PostgreSQL nedeniyle bağlantı hataları oluştu; aynı socket/
port ile yeniden başlatıldı. Sonrasında tam suite, eşzamanlı fixture DDL hazırlığında
XX000 tuple concurrently updated üretti; PostgreSQL kullanan test sınıfları aynı xUnit
collection'a alındı. Gerçek eşzamanlı istemci transaction testleri Task.WhenAll ile
korundu. Browser testinde native option görünürlük beklemesi attached olarak düzeltildi.
Bu ara başarısızlıklar saklanmadı; son tam koşu yukarıdaki PASS sonucudur.

Uyumluluk/sınırlar: no-query vessel list artık 500 yerine 50 kayıt döndürür. items
alanı korunur; tüm in-repo gemi tüketicileri continuation'a uyarlandı. Dış istemci
tek cevabı tam liste saymamalıdır. Certificate list eski 500 sınırında kaldı. Query
ASCII-only case folding kullanır; tam Türkçe collation yok. Cursor snapshot değildir:
cursor öncesi insert ancak restart'ta görünür, update filtre üyeliğini değiştirebilir.
Büyük veri performansı/üretim indeks planı, gerçek IdP/hosting/TLS, diğer tarayıcılar,
gerçek mobil/ekran okuyucu/full WCAG NOT_RUN'dır. UAT adımları source/docs içindedir.

Arşiv tam güncel takipli kaynak + yeni dosyalar, temiz tabana uygulanabilir patch,
SHA-256 manifesti, sonuç JSON'u ve temiz test kanıtlarını içerir. DB/env/secrets,
node_modules, bin/obj/dist, .git veya screenshot yoktur. Tarihsel kaynak doğrulama
belgeleri korunmuştur; bu rapor ve result.json bu dilimin güncel sonuçlarıdır.
