# İdari belge kayıtları ve tarih takibi — inceleme adayı

Taban: `cdb39a5658dd5d2f6036e1cd52c9608b9b25fedf`, tree
`2289a5408d1d592e05e350a048946cd456b0b626`. Başlangıçtaki83 dosya yayımlanan feature
kaynağıyla byte düzeyinde eşleşti; kullanıcı değişikliği yoktu. Yeni patch bu tabana
göredir; main008b6105'e göre değildir. Teslim99 kaynak dosyası,28 değişen/yeni dosya.
Commit/push/merge/hosting/deployment veya gerçek hesap/grant/IdP yapılmadı.

Tamamlanan idari yolculuk: yetkili vessel/tug seçimi; vessel-only eksik DRAFT;
metadata; bağımsız certificate:manage ile RECORDED; gerekçeli kayıtlı metadata
düzeltme/reopen; bounded liste/filtre/paging/detail; redakte tarihçe. Kayıtlı parent
seçilebilir; parent reopen belge state/sürümünü değiştirmez. Yedi mevcut metadata
alanı, sabit UUID ve immutable vessel korunur. Gelecek issue yalnız uyarıdır;
expiry yokluğu perpetual/valid değildir. Hiçbir ekran doğrulama veya operasyon onayı vermez.

Sunucu UTC DateOnly kovaları tam sınırlarıyla uygulanır. Page cursor asOfDate'i gece
yarısında korur; refresh yeni güne geçer. Tarih geçmesi state/version/audit değiştirmez.
Cursor consistency hash'tir; kriptografik server-origin veya historical snapshot
garantisi değildir. Kullanılan asOfDate açıkça görünür; bu sınır ADR'de belgelendi.

Yeni003 migration eski sertifikaları DRAFT/schema1 bırakır, mevcut inventory/state,
UUID/FK/owner/audit/idempotency korunur. Legacy v2/RECORDED write/replay409; RECORDED
single GET409; eski collection DRAFT-only; submit403. DB eski UPDATE koruması iki
aggregate türüne uygulanır. Eski binary rollback güvenli ilan edilmez.

Son teknik kanıt:

- Backend **139 PASS,0 FAIL,0 SKIP**: önceki129 +10 yeni test. Sabit saat/midnight,
  on tarih sınırı, bağımsız grant/parent isolation, original-action replay yetkisi,
  concurrency,601 kayıtlı pagination, literal wildcard, strict input/date, güvenli
  history, gerçek migration ve audit failure rollback dahil.
- Frontend **92 PASS,0 FAIL,0 SKIP**: önceki74 +18 yeni test. Dirty navigation,
  parent picker, unknown outcome/rejected replay key retention, confirmedId read retry,
  logout barrier, expiry, stale query, held asOf/refresh, reason, XSS/plain text dahil.
- .NET locked restore/build (0 warning/error), TypeScript ve default/BFF frontend
  build PASS; yeni paket kurulmadı.
- BFF tarayıcı matrisi **6/6 PASS**:390/768/1440 × TR/EN; gerçek Chromium154,
  React/ASP.NET/PostgreSQL. Belge yolculuğu, RECORDED parent, no-expiry, reason,
  expiry+30/gfuture issue, reopen/re-record, history redaction ve dirty cancel.
  Hawaii/Kiritimati browser timezone'larında aynı frozen server UTC2026-10-27 ve
  expiry2026-11-26 =30 gün. Önceki inventory logout/uncertain replay regresyonları korunur.
- Legacy responsive/klavye matrisi **6/6 PASS**. Dördüncü nav öğesinin ilk birleşik
  koşuda yarattığı390px taşma bulundu, mobil iki sütun sarmasıyla düzeltildi ve
  son iki matris yeniden geçti. İlk hatalı koşu başarı sayılmadı.
- Loopback sentetik UAT betiği gerçekten çalıştı: bir DRAFT parent, bir partial belge,
  altıRECORDED tarih örneği. Bu bir hesap/IdP provisioning veya kullanıcı UAT'si değildir.

Bağımsız kaynak incelemesi backend ve frontend için yapıldı. Yeni somut security/
concurrency/replay kusuru bulunmadı. Missing vessel hatasının aria bağlantısı eksiği
saptandı, düzeltildi ve test edildi. İnceleyen test çalıştırmadı; yukarıdaki PASS'ler
birleşik kaynak üzerinde gerçekten yürütülen koşulardır.

Sınırlar ve açık kapılar:

- **PRIVATE_ACCESS_NOT_ESTABLISHED; USER_ACCEPTANCE_PENDING.** Kullanıcının açabildiği
  özel Android/web URL'si yok; localhost/Library/görev bağlantısı uygulama erişimi değildir.
- BFF HTTPS ve redirect taşınması Playwright–stdio–TestServer köprüsüdür. Provider,
  ticket ve anahtarlar test-only ephemeral; nativeTLS/liveIdP/federasyon NOT_RUN.
- Gerçek mobil donanım, native browser Back/Forward/BFCache, screen reader/tamWCAG,
  offline ve gerçek kurum release işletimi NOT_RUN. UI listesine dönüş/dirty menü iptali
  ve viewport/klavye testleri bunların yerine geçmez.
- G1–G7 açıktır: catalogue/applicability, Evidence, verification authority,
  survey/renewal, readiness/PSC, outbox/notifications/offline, deployment/UAT.
  Yedi ekranlı tam sertifika/sörvey veya tüm v46.3 ürün tamamlandı denmez.

Arşiv complete source, baseline patch, hash manifestleri, ADR/API eki, UAT adımları,
synthetic fixture ve sanitized kanıtları içerir. Screenshots, secrets, gerçek kullanıcı
verisi, veritabanı, node_modules ve bin/obj yoktur. Kalan tek teslim erişim engeli,
kullanıcıya güvenli özel uygulama erişiminin henüz kurulmamış olmasıdır; yasaklı işlem
denenmedi, otomatik onay reddi veya sonucu belirsiz uzak işlem yoktur.
