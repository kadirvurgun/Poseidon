# Poseidon BFF UI — doğrulanmış teslim

Taban/HEAD: ad4407639950d2af4440bbd3650c20142854d208.
Yayımlanan 57 dosya yerel kaynakla birebir karşılaştırılarak tabana geçildi; kullanıcı
çalışması kaybedilmedi. Yerel commit, push, merge veya deployment yapılmadı.

Uygulandı: varsayılan kapalı React BFF modu; aynı HTTPS kökeninde explicit login,
server-side cookie session restore, CSRF'li logout; oturum sona erince düzenlemeleri
koruyup yazmayı dondurma; iptal edilen navigation/logout/relogin'de veri koruma;
onaylanan yeniden giriş/çıkışta veriyi bırakma; otomatik yazma retry'si olmaması.
Yeni /bff/api/v1/vessels ve certificates rotaları cookie policy + CSRF + scope
önkoşulu kullanır; bearer /api/v1 rotaları cookie kabul etmez. Ortak domain store
aynı DRAFT/tenant/company/vessel/idempotency/version/audit denetimlerini uygular.
X-Poseidon-Scope halka açık bir concurrency önkoşuludur; yetki veya credential değildir.
Sunucu çözümlediği scope ile karşılaştırır. Başka sekmede hesap/kapsam değişirse eski
istemcinin işlemi 401 olur. JS auth token almaz; state yalnız bellektedir.

Son doğrulamalar:
- Backend 92 PASS, 0 FAIL, 0 SKIP. Önceki 86 test korunur. Gerçek PostgreSQL dahil.
- Frontend 47 PASS, 0 FAIL, 0 SKIP. Önceki 35 test korunur.
- Locked restore PASS, backend build 0 uyarı/0 hata, frontend typecheck/build PASS.
- Altı mevcut viewport/dil matrisi: 390/768/1440 × TR/EN PASS; taslak POST sayısı 0.
  Bu son tekrar güncel backend derlemesiyle özel Development servisinde yapıldı.
- Yeni gerçek Chromium BFF testi: TR/EN PASS. Login/callback/cookie, gemi ve sertifika
  taslağı kaydı, dirty navigation/logout iptali, expiry, relogin iptali/onayı, logout
  ve reload doğrulandı. Her dilde 2 başarılı taslak POST, expiry sonrası 1 reddedilen
  POST; otomatik retry 0. HttpOnly/Secure cookie ve browser storage boşluğu kontrol edildi.

BFF browser testinde derlenmiş React, gerçek ASP.NET OIDC/cookie handler ve PostgreSQL
birliktedir. Fake IdP/token endpoint'i process-only; RSA ve Data Protection geçicidir.
Playwright HTTPS isteklerini stdio köprüsüyle TestServer'a taşır. Fulfilled redirect
zincirinin route edilmeme sınırı yüzünden handler'ın gerçek Location cevabı kontrollü
navigation ile relay edilir. Native HTTP redirect/TLS taşıması ve dış IdP uyumluluğu
DOĞRULANMIŞ DEĞİLDİR. Sahte signin endpoint'i browser akışında kullanılmaz.

Kesinti: final test sırasında executor bağlantısı koptu. Aynı executor geri geldiğinde
çalışma ağacı ve final 89 PASS/build çıktısı doğrulandı. Kaynak bellekten yeniden
oluşturulmadı, ortam değiştirilmedi. Eski yerel API süreci güncel derleme ile yeniden
başlatıldı; viewport matrisi tekrar geçti. Çözülmemiş bağlantı engeli yoktur.

Açık sınırlar: gerçek IdP/AD/SSO/kurum içi hesap provisioning, gerçek credential/client
kaydı, persisted key/ticket store kurulumu, refresh, federasyon logout, harici downstream
API proxy, production proxy/HTTPS, diğer tarayıcılar/gerçek mobil/ekran okuyucu/tam WCAG.
Bu kapılar ayrı kurulum/onay bekler. Yeni modun iki opt-in kapısı da varsayılan kapalıdır;
frontend BFF seçildiğinde bearer/sentetik UI'ya sessiz fallback yapılmaz. Gerçek hesap,
sertifika, kalıcı key veya güvenlik ayarı oluşturulmadı/değiştirilmedi.

Arşiv: güncel tüm takipli kaynak + yeni kaynaklar, tabana karşı patch, kaynak SHA-256
manifesti, JSON sonuçlar ve temiz test kanıtları içerir. Tarihsel doğrulama belgeleri
kaynak snapshot'ında korunur; bu rapor ve result.json bu dilimin son durumudur.
Secrets/gerçek DB/env, node_modules, bin/obj/dist, .git veya screenshot yoktur.
Takipli .env.example yalnız false opt-in örnekleri içerir.

## P2 bağımsız inceleme düzeltmesi

A sekmesinin B oturumunu kapatması engellendi. Logout, CSRF yanında gösterilen hesabın
server-validated X-Poseidon-Scope önkoşulunu zorunlu tutar. React fresh client oluşturmaz;
A'yı doğrulamış client ve sabit scope'u kullanır. CSRF yanıtı beklenirken cookie B'ye
geçse bile A scope'u korunur. Mismatch/eksik scope 409 logout_scope_changed döner;
B ticket/cookie'sine sign-out yapılmaz. UI çıkış yapılmadığını TR/EN bildirir, eski
client'ı invalid eder ve dirty veriyi korur. Sonraki stale-client yerel çıkışı B'ye
server isteği göndermez. Üç server regresyonu ve deferred A→B istemci regresyonu geçti.
Bu sürüm aynı Library kimliğinin önceki adayını değiştirir; taban ad440763 korunur.
