export type Kind = "vessels" | "certificates";
export type DraftData = Record<string, string>;
export interface Session {
  subject: string;
  tenantId: string;
  companyId: string;
  vesselIds: string[];
  synthetic: boolean;
}
export interface Draft {
  draftId: string;
  version: number;
  persistenceState: "DRAFT";
  submissionAllowed: false;
  data: DraftData;
}
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public errors: Record<string, string[]> = {},
  ) {
    super(message);
  }
}
function checkedDraft(value: Draft): Draft {
  if (
    !value ||
    typeof value.draftId !== "string" ||
    !Number.isSafeInteger(value.version) ||
    value.version < 1 ||
    value.persistenceState !== "DRAFT" ||
    value.submissionAllowed !== false ||
    !value.data ||
    typeof value.data !== "object" ||
    Array.isArray(value.data) ||
    Object.values(value.data).some((v) => typeof v !== "string")
  )
    throw new ApiError(
      0,
      "INVALID_RESPONSE",
      "Server response did not confirm a draft.",
    );
  return value;
}
export class Api {
  private invalidated = false;
  private browserScope: string | null = null;
  invalidate() { this.invalidated = true; }
  constructor(
    public token: string,
    protected transport: typeof fetch = fetch,
    private mode: "bearer" | "bff" = "bearer",
  ) {}
  protected async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    if (this.invalidated) throw new ApiError(401, "SESSION_ENDED", "Session ended.");
    const browser = this.mode === "bff";
    const scopedRequest = browser && path !== "/session";
    if (scopedRequest && !this.browserScope) throw new ApiError(401, "SESSION_REQUIRED", "Verify session first.");
    const csrf = browser && init.method === "POST" ? await this.antiforgery() : null;
    // A request waiting for CSRF must not resume after logout/expiry.
    if (this.invalidated) throw new ApiError(401, "SESSION_ENDED", "Session ended.");
    let response: Response;
    try {
      // Native browser fetch must not receive the Api instance as its receiver.
      const transport = this.transport;
      const url = browser ? (path === "/session" || path === "/logout" ? `/bff${path}` : `/bff/api/v1${path}`) : `/api/v1${path}`;
      response = await transport(url, {
        ...init,
        credentials: browser ? "same-origin" : "omit",
        redirect: "error",
        headers: {
          "Content-Type": "application/json",
          ...(csrf ? { "X-CSRF-TOKEN": csrf } : {}),
          ...(scopedRequest ? { "X-Poseidon-Scope": this.browserScope! } : {}),
          ...(!browser && this.token ? { Authorization: `Bearer ${this.token}` } : {}),
          ...init.headers,
        },
      });
    } catch {
      throw new ApiError(
        0,
        "NETWORK_ERROR",
        "The server could not be reached. The save outcome may be unknown.",
      );
    }
    const body = await response.json().catch(() => ({}));
    if (browser && (response.status === 401 || body.code === "logout_scope_changed")) this.invalidate();
    if (!response.ok)
      throw new ApiError(
        response.status,
        body.code || "HTTP_ERROR",
        body.message || `HTTP ${response.status}`,
        body.errors,
      );
    return body as T;
  }
  async antiforgery(): Promise<string> {
    const transport = this.transport;
    const response = await transport("/bff/antiforgery", { credentials: "same-origin", redirect: "error", cache: "no-store" });
    if (!response.ok) throw new ApiError(response.status, "CSRF_UNAVAILABLE", "Request verification unavailable.");
    const body = await response.json();
    if (typeof body.requestToken !== "string" || !body.requestToken) throw new ApiError(0, "INVALID_RESPONSE", "Request verification unavailable.");
    return body.requestToken;
  }
  async session() {
    const active = await this.request<Session>("/session");
    if (this.mode === "bff") {
      if (!active || !active.subject || !active.tenantId || !active.companyId) throw new ApiError(0, "INVALID_SESSION", "Invalid session response.");
      const stamp = `${active.subject}:${active.tenantId}:${active.companyId}`;
      if (this.browserScope && this.browserScope !== stamp) {
        this.invalidate(); throw new ApiError(401, "SESSION_CHANGED", "Session changed.");
      }
      this.browserScope = stamp;
    }
    return active;
  }
  devSession(fixture: string) {
    return this.request<{ accessToken: string; session: Session }>(
      "/dev/session",
      { method: "POST", body: JSON.stringify({ fixture }) },
    );
  }
  async list(kind: Kind) {
    const result = await this.request<{ items: Draft[] }>(`/${kind}`);
    if (!Array.isArray(result.items))
      throw new ApiError(
        0,
        "INVALID_RESPONSE",
        "Server did not return a draft list.",
      );
    return { items: result.items.map(checkedDraft) };
  }
  async get(kind: Kind, id: string) {
    return checkedDraft(
      await this.request<Draft>(`/${kind}/${encodeURIComponent(id)}`),
    );
  }
  async save(kind: Kind, data: DraftData, key: string, record?: Draft) {
    return checkedDraft(
      await this.request<Draft>(
        `/${kind}${record ? `/${encodeURIComponent(record.draftId)}` : ""}`,
        {
          method: "POST",
          headers: {
            "Idempotency-Key": key,
            ...(record ? { "If-Match": `"${record.version}"` } : {}),
          },
          body: JSON.stringify({ saveMode: "DRAFT", data }),
        },
      ),
    );
  }
}
export const newRequestKey = () => crypto.randomUUID();

// Cookie-only browser transport: no access/ID/refresh token is returned to JavaScript.
export class BffApi extends Api {
  constructor(transport: typeof fetch = fetch) { super("", transport, "bff"); }
  async logout() { await this.request("/logout", { method: "POST" }); this.invalidate(); }
}

export async function beginBffLogin(lang: "tr" | "en", beforeNavigate: () => void = () => {}) {
  const csrf = await new BffApi().antiforgery();
  // Top-level form navigation lets the handler challenge the IdP; never fetch its redirect.
  // Fixed local return URL, independent of caller URL/query parameters.
  const form = document.createElement("form");
  form.method = "POST"; form.action = `/bff/login?returnUrl=${encodeURIComponent("/?lang=" + lang)}`;
  const field = document.createElement("input");
  field.type = "hidden"; field.name = "__RequestVerificationToken"; field.value = csrf;
  form.append(field); document.body.append(form);
  beforeNavigate();
  try { form.submit(); } finally { form.remove(); }
}
