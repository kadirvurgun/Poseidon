// Real Chromium + built React, bridged to ASP.NET TestServer over stdio.
// HTTPS is virtual within Playwright routing: no TLS certificate, socket IdP or real identity.
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/opt/codex/cua_node/lib/node_modules/playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const readline = require('node:readline');
let sequence = 0;
const pending = new Map();
readline.createInterface({input: process.stdin}).on('line', line => { const value = JSON.parse(line); pending.get(value.id)?.(value); pending.delete(value.id); });
const rpc = data => new Promise(resolve => { const id = ++sequence; pending.set(id, resolve); process.stdout.write(JSON.stringify({id, ...data}) + '\n'); });
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
  const results = [];
  try {
    for (const lang of ['tr', 'en']) {
      const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
      const page = await context.newPage();
      page.setDefaultTimeout(15000);
      let writes = 0, authorize = 0, cancel = false;
      page.on('dialog', dialog => cancel ? dialog.dismiss() : dialog.accept());
      const t = (tr, en) => lang === 'tr' ? tr : en;
      const button = name => page.getByRole('button', {name, exact: true});
      await context.route('**/*', async route => {
        const request = route.request(); const url = new URL(request.url());
        console.error("route", request.method(), url.origin + url.pathname);
        if (url.origin === 'https://issuer.invalid' && url.pathname === '/authorize') {
          authorize++;
          await rpc({op: 'authorize', nonce: url.searchParams.get('nonce'), challenge: url.searchParams.get('code_challenge')});
          const state = url.searchParams.get('state'); assert.match(state, /^[a-zA-Z0-9_-]+$/);
          await route.fulfill({contentType:'text/html', body:`<form method="post" action="https://localhost/bff/callback"><input name="code" value="isolated-code"><input name="state" value="${state}"></form><script>document.forms[0].submit()</script>`}); return;
        }
        assert.equal(url.origin, 'https://localhost');
        if (url.pathname.startsWith('/bff/')) {
          if (request.method() === 'POST' && url.pathname.startsWith('/bff/api/')) writes++;
          const response = await rpc({op:'request', url:request.url(), method:request.method(), headers:await request.allHeaders(), body:request.postData()});
          console.error("response",url.pathname,response.status);
          if (response.status >= 300 && response.status < 400 && response.headers.location) {
            // Playwright does not reroute a fulfilled redirect chain. Relay the handler's
            // exact Location as a new navigation, retaining its original Set-Cookie headers.
            // This tests handler + browser state, not native HTTP redirect/TLS transport.
            const target = new URL(response.headers.location, url).href;
            assert(['https://localhost', 'https://issuer.invalid'].includes(new URL(target).origin));
            delete response.headers.location; delete response.headers['content-length'];
            response.headers['content-type'] = 'text/html';
            await route.fulfill({status:200,headers:response.headers,body:'<script>location.replace('+JSON.stringify(target).replaceAll('<','\\u003c')+')</script>'}); return;
          }
          await route.fulfill({status:response.status, headers:response.headers, body:Buffer.from(response.body,'base64')}); return;
        }
        assert(!url.pathname.startsWith('/api/'), 'BFF UI must never call bearer API');
        const relative = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
        const target = path.resolve(process.env.POSEIDON_BFF_BROWSER_DIST, relative);
        assert(target.startsWith(path.resolve(process.env.POSEIDON_BFF_BROWSER_DIST) + path.sep));
        await route.fulfill({body: fs.readFileSync(target), contentType: relative.endsWith('.js') ? 'text/javascript' : relative.endsWith('.css') ? 'text/css' : 'text/html'});
      });
      await page.goto('https://localhost/?lang='+lang);
      await button(t('Giriş yap','Sign in')).waitFor(); assert.equal(authorize,0);
      await button(t('Giriş yap','Sign in')).click();
      await button(t('Yeni taslak','New draft')).waitFor(); assert.equal(authorize,1);
      assert.equal(await page.locator('#token').count(),0);
      const cookie = (await context.cookies()).find(c => c.name === '__Host-Poseidon.Session');
      assert(cookie && cookie.secure && cookie.httpOnly);
      assert(!(await page.evaluate(() => document.cookie)).includes('Poseidon.Session'));
      assert(!cookie.value.includes('callback-subject'));
      await button(t('Yeni taslak','New draft')).click(); await page.locator('#name').fill('Browser BFF '+lang);
      await button(t('Taslağı kaydet','Save draft')).click();
      await page.getByText(t('Taslak sunucuya kaydedildi.','Draft saved to the server.'),{exact:true}).waitFor();
      await button(t('Sertifika taslakları','Certificate drafts')).click();
      await button(t('Yeni taslak','New draft')).click();
      await page.locator('#vessel_id').selectOption({label: await page.locator('#vessel_id option').filter({hasText:'Browser BFF '+lang}).last().textContent()});
      await page.locator('#type').fill('BFF isolated certificate');
      await button(t('Taslağı kaydet','Save draft')).click();
      await page.getByText(t('Taslak sunucuya kaydedildi.','Draft saved to the server.'),{exact:true}).waitFor();
      await page.locator('#type').fill('Unsaved retained '+lang);
      cancel = true; await button(t('Gemi taslakları','Vessel drafts')).click();
      assert.equal(await page.locator('#type').inputValue(),'Unsaved retained '+lang);
      await button(t('Çıkış','Sign out')).click(); assert.equal(await page.locator('#type').inputValue(),'Unsaved retained '+lang);
      await rpc({op:'expire'});
      const beforeExpiryWrites = writes;
      await button(t('Taslağı kaydet','Save draft')).click();
      await page.getByText(t('Oturum sona erdi.','Session ended.'),{exact:true}).waitFor();
      assert.equal(await page.locator('#type').inputValue(),'Unsaved retained '+lang);
      assert(await button(t('Taslağı kaydet','Save draft')).isDisabled());
      await button(t('Yeniden giriş yap','Sign in again')).click(); assert.equal(authorize,1);
      cancel = false; await button(t('Yeniden giriş yap','Sign in again')).click();
      await button(t('Yeni taslak','New draft')).waitFor(); assert.equal(authorize,2);
      assert.equal(await page.locator('#type').count(),0);
      assert.equal(writes,beforeExpiryWrites+1); // one rejected request, no automatic retry
      await button(t('Çıkış','Sign out')).click(); await button(t('Giriş yap','Sign in')).waitFor();
      await page.reload(); await button(t('Giriş yap','Sign in')).waitFor(); assert.equal(authorize,2);
      const storage = await page.evaluate(() => ({local:localStorage.length, session:sessionStorage.length, cookie:document.cookie}));
      assert.equal(storage.local,0); assert.equal(storage.session,0); assert(!storage.cookie.includes('Poseidon.Session'));
      results.push({lang, status:'PASS', successfulDraftWrites:2, rejectedAfterExpiry:1, automaticRetries:0, logins:authorize, virtualHttps:true});
      await context.close();
    }
    if (process.env.POSEIDON_BFF_BROWSER_REPORT) fs.writeFileSync(process.env.POSEIDON_BFF_BROWSER_REPORT, JSON.stringify({chromium:browser.version(),results},null,2));
  } finally { await browser.close(); }
})().then(() => process.exit(0)).catch(error => { console.error(error); process.exit(1); });
