import pathlib,os,json,importlib.util,contextlib,io,subprocess,sys
from unittest.mock import patch
old=pathlib.Path('/workspace/Poseidon-startup-cause-fix');new=pathlib.Path('/workspace/Poseidon-targeted-stop')
home=pathlib.Path('/workspace/poseidon-diag-xy2uffmp');state=home/'.poseidon-synthetic-uat';data=state/'pgdata';sock=state/'socket'
assert json.loads((state/'owner.json').read_text())=={'purpose':'poseidon-synthetic-uat-v1','repository':str(old)}
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
supervisor=load('owned_fixture_supervisor',old/'scripts/uat.py');helper=load('stop_fixture',new/'scripts/uat-stop-task-db.py');helper.diag.ROOT=old
# Fixture was created without run(); create its own empty supervisor inode once.
lock=state/'supervisor.lock'
if not lock.exists():lock.touch(mode=0o600)
env=supervisor.clean_env(os.environ);env['LD_LIBRARY_PATH']=os.environ.get('LD_LIBRARY_PATH','')
def sql(text):return subprocess.check_output(['psql','-XAt','-h',str(sock),'-p','55433','-d','postgres','-c',text],env=env,text=True,stderr=subprocess.PIPE).strip()
c=supervisor.OwnedPostgres(data,sock,state,env)
try:
 c.start();sql('CREATE TABLE IF NOT EXISTS synthetic_stop_preservation(id integer PRIMARY KEY); INSERT INTO synthetic_stop_preservation VALUES (7) ON CONFLICT DO NOTHING')
 with patch.object(helper.pathlib.Path,'home',return_value=home),patch.object(sys,'argv',['uat-stop-task-db.py','--graceful']),contextlib.redirect_stdout(io.StringIO()) as out:
  code=helper.main()
 assert code==0 and out.getvalue().strip()=='TASK_DB_STOPPED'
 c.process.wait(timeout=5);c.close()
 c=supervisor.OwnedPostgres(data,sock,state,env);c.start();assert sql('SELECT id FROM synthetic_stop_preservation')=='7'
 c.close()
 print(json.dumps({'result':'PASS','helperOutput':'TASK_DB_STOPPED','actualLinuxPidfdGracefulSignal':True,'sameClusterRestartAndSyntheticRowPreserved':True,'noNewDatabase':True,'allOwnedChildrenStopped':True,'fixtureOwnerPathAdaptation':'Test module ROOT points to existing fixture checkout; on-disk marker unchanged','ownerCodespaceTouched':False},indent=2))
finally:c.close()
