# Görev DB'si için kontrollü graceful recovery

Taban 851cd41a341c5f3f2054bcba4f19513762f45d1b. Yeni yardımcı yalnız açık
--graceful komutuyla sabit HOME görev kümesini hedefler. Mevcut supervisor kilidi
boş olmalı; kilit build/runtime owner ile koordinasyonu korur. /proc/self namespace
kontrolü eklendi. pidfd_open sonrası tam kimlik/SQL/peer/snapshot kontrolü yenilenir;
signal.pidfd_send_signal ile yalnız pinli process'e SIGTERM gider. PID reuse'a
karşı sayısal PID sinyali kullanılmaz. 30 saniye timeout'ta escalation yok;
PID/socket dosyaları otomatik silinmez. Launcher'ın no-adoption kuralı değişmedi.

72 test PASS. Negatifler: busy supervisor, PID/peer değişimi, başarısız diagnostic,
namespace, desteklenmeyen pidfd, timeout, residual dosyalar, symlink/missing lock,
bozuk argüman ve safe error output. Gerçek task-owned PostgreSQL fixture'ında
smart shutdown, aynı kümede restart ve sentetik satır korunması PASS. Tüm fixture
child'ları durdu. Yeni DB yok; fixture ROOT path test modülünde mevcut owner ile
eşlendi, diskteki marker değişmedi. Kullanıcı Codespace'inde işlem yapılmadı.

İnceleme/yayın sonrası tek komut: python3 scripts/uat-stop-task-db.py --graceful.
Yalnız TASK_DB_STOPPED sonrası normal launcher bir kez çalıştırılabilir. Diğer
çıktılar ret/pending/belirsizdir; retry/force/PID silme talimatı verilmez.
Önceki aa51 ilk exception kalıcı kaydedilmedi; şimdi geri alındığı iddia edilmez.
İlk launcher PID mismatch root cause hâlâ UNKNOWN. Bu recovery root cause fix
veya production/UAT acceptance iddiası değildir. No push/commit/deploy.

Backend/frontend/browser kodu değişmedi, bu tur NOT_RERUN. 137 tam kaynak,
baseline patch, hash ve test kanıtları dahil; secret, DB veya screenshot yok.
