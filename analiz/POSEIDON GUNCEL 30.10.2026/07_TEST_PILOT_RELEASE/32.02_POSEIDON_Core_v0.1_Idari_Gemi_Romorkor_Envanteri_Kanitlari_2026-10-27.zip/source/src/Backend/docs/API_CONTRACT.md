# Draft API contract (development implementation)

Base URL configured through ASPNETCORE_URLS; suggested http://127.0.0.1:5080.
All API endpoints require Bearer authentication except the explicit Development-only
synthetic session endpoint. Public GET /health/ready returns HTTP 200 or 503:
`{"status":"ready|not_ready","persistence":"PostgreSQL"}`; checks connectivity,
PostgreSQL >=17 and required tables; no secrets. No external IdP is yet configured.

| Method | Route | Result |
|---|---|---|
| POST | /api/v1/dev/session | Only explicit Development mode, fixture login |
| GET | /api/v1/session | Current verified/synthetic session |
| GET | /api/v1/vessels | `{items:Draft[]}` |
| POST | /api/v1/vessels | Create metadata draft |
| GET | /api/v1/vessels/{draftId} | Draft + ETag |
| POST | /api/v1/vessels/{draftId} | Replace draft metadata + ETag |
| GET | /api/v1/certificates | `{items:Draft[]}` |
| POST | /api/v1/certificates | Create metadata draft |
| GET | /api/v1/certificates/{draftId} | Draft + ETag |
| POST | /api/v1/certificates/{draftId} | Replace metadata + ETag |
| POST | /api/v1/{vessels or certificates}/{draftId}/submit | Always 403 |

Save request `{saveMode:"DRAFT",data:{...}}`; Idempotency-Key UUID header mandatory.
Updates require If-Match header with quoted positive version (`"1"`). Missing fields
are removed on replacement. HTTP 200 save/read Draft:
`{draftId:UUID,version:number,persistenceState:"DRAFT",submissionAllowed:false,data:{...}}`.
ETag is quoted version; no automatic finalization. No DELETE or verified state.
Vessel fields: name, company_id, imo_no, official_no, flag, vessel_type, notes.
Certificate fields: vessel_id, type, certificate_no, issuer, issue,
expiry, notes. Values must be nonblank strings or omitted; metadata optional
except certificate vessel_id for authorization. UUID refs; dates YYYY-MM-DD; IMO seven
digits. Unknown/duplicate/forged fields rejected. Notes max4000; other strings max200.
List limited to 500; no pagination contract yet.

Errors `{code:string,message:string}`: 400 invalid JSON/missing idempotency key;
403 submission disabled/company scope; 404 draft or vessel inaccessible;
409 idempotency conflict; 412 stale version; 422 invalid provided data;
428 missing update version; 503 database failure (save not confirmed).
Framework 401/403 authentication/authorization failures may have empty bodies.

Default OAuth2 bearer JWT auth: Authentication__Authority HTTPS, Authentication__Audience;
validated server claims sub, tenant_id, company_id, repeated vessel_id; writes also
permission=draft:write. X-Tenant headers ignored. New vessels accessible to creator
subject only, or explicitly signed vessel_id claim; company/tenant enforced separately.

Synthetic mode: ASPNETCORE_ENVIRONMENT=Development and SyntheticIdentity__Enabled=true.
Any other environment with synthetic enabled fails startup. No static passwords or
shared admin tokens. POST /api/v1/dev/session `{fixture:"tenant-a"}` returns
`{accessToken:string,session:{subject,tenantId,companyId,vesselIds:UUID[],synthetic:true}}`.
Fixtures tenant-a, tenant-b, tenant-a-restricted. A restricted shares A tenant/company
but owns no A vessels. Tokens random, in-process, expire after one hour.
GET /api/v1/session returns the inner session object. Database__Initialize=true is
also Development-only, applying schema and synthetic company seed. Details in ../README.md.

Additional negative-test fixtures: tenant-a-other-company uses the same synthetic-a subject in a different company of tenant A; tenant-a-readonly has no draft:write permission. These exist only in explicit Development synthetic mode.

Controlled16.01 alignment: CertificateDraftFields canonical shared keys are exactly
vessel_id/type/issuer/issue/expiry. Former unpublished certificate_type/issue_date/
expiry_date keys are rejected (422 unknown_field). certificate_no and notes are
explicit development extensions, as are certificate detail/update and explicit
submit-rejection routes. No controlled-source file was modified for this correction.

## INVENTORY-001 browsing extension (2026-10-27)

Vessel GET lists now accept q, flag, vessel_type, pageSize and cursor and return
`{items,nextCursor,hasMore}`. No-query default changed from first500 to first50;
max pageSize100. Certificate lists retain the earlier bound. New query semantics
are implementation decisions, not pre-existing canonical approval. Both bearer and
explicit BFF vessel routes use the same scope-checked keyset query. See
[ADR_INVENTORY_BROWSING.md](../../../docs/ADR_INVENTORY_BROWSING.md) for strict input
bounds, literal wildcards, ASCII-only folding, query/scope-bound cursor, compatibility
and non-snapshot caveats. No history-read or new lifecycle endpoint is added.

## ADR-INV-ADMIN-001–004: ayrı idari envanter yüzeyi

Yeni uygulama kararları, eski kanonik lifecycle onayı değildir. Ayrıntılar:
`docs/ADR_INVENTORY_ADMIN.md`. Bearer kökü `/api/v1/inventory/vessels`;
cookie kökü `/bff/inventory/vessels`. Cookie tüm mutasyonlarında CSRF ve tüm
isteklerde X-Poseidon-Scope zorunlu. API tokenları/BFF cookie'leri birbirine genişlemez.

- GET collection: mevcut q/flag/vessel_type/pageSize/cursor + exact
  `adminState=DRAFT|RECORDED`, `asset_mode=SHIP|TUG`; items/nextCursor/hasMore.
- GET /capabilities: çağıranın canWriteDraft/canManage yetenekleri; nesne yetkisi değildir.
- GET /{id}: `{id,version,adminState,data,completeness,createdAt,modifiedAt}` + ETag.
  completeness `{missingRequiredFields,invalidFields}`; uyumluluk yüzdesi yok.
- POST collection `{data:{...}}`: eksik DRAFT; şirket sunucudan. create-as-RECORDED yok.
- POST /{id}/metadata `{data:{...}}`: tam yeni metadata replacement.
- POST /{id}/commands/record: `{}` veya boş body; yalnız DRAFT→RECORDED.
- POST /{id}/commands/reopen `{reason:"..."}`: yalnız RECORDED→DRAFT.
- GET /{id}/history: dar alan adları/SELF-OTHER projeksiyonu; ayrı cursor ve pageSize20/100.

Her yazıda Idempotency-Key UUID; güncelleme/komutlarda quoted If-Match. Eksik 428,
bozuk anahtar 400, eski sürüm 412, action grant eksik 403, nesne yok/yetkisiz404,
metadata422, geçiş/idempotency çakışması409. Metadata DRAFT'ta draft:write,
RECORDED'ta inventory:manage; record/reopen inventory:manage. UI yetki düğmeleri
sunucu denetiminin yerine geçmez. Versioned aggregate/audit/replay atomik.

Legacy `/api/v1/vessels` ve BFF draft karşılığı yalnız DRAFT listeler. schema2 DRAFT
okuması sınırlı yedi eski string alanıdır; geniş metadata için yeni route şart.
schema2 veya RECORDED legacy yazı/replay409 inventory_resource_required. RECORDED
legacy single GET409; hiçbir cevap yanlış DRAFT iddiası üretmez. Legacy submit403.
Sertifika taslak kayıtları değişmedi; RECORDED gemiye yetkili bağlantı mümkündür.
Arayüzde eski Gemi taslakları sekmesi uyumluluk görünümüdür; tam yeni idari yönetim
İdari envanter sekmesindedir. Sertifika gemi seçimi yeni tam inventory reader kullanır.
