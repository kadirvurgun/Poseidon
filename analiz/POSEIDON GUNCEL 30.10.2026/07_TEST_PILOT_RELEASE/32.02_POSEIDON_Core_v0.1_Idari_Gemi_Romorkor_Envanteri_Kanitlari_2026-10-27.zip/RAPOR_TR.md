# İdari gemi/römorkör envanteri — inceleme adayı

Taban: `008b6105b1d964373bd7a92ee032b51b4a7ae00f`.
83 kaynak dosyası; 31 değişen/yeni dosya. Başlangıçtaki 67 dosya tabanla byte düzeyinde
karşılaştırıldı, fark yoktu. Çalışma ağacı korunarak yerel taban hizalandı. Commit,
push, merge, deployment, public preview veya gerçek hesap/IdP/grant oluşturulmadı.

İdari yolculuk tamamlandı: eksik DRAFT oluşturma; tam beyan metadata düzeltme;
açık SHIP/TUG seçimi; bağımsız inventory:manage ile RECORDED; gerekçeli reopen;
yeniden kayıt; scope bağlı liste/filtre/sayfalama/detail ve değer göstermeyen tarihçe.
TR/EN arayüz yeni İdari envanter sekmesindedir. Eski Gemi taslakları uyumluluk
sekmesi korunur; tam yeni metadata yönetimi buradan yapılmaz. Certificate picker
DRAFT ve RECORDED gemileri yeni inventory reader üzerinden seçer.

Yeni 002 migration eski gemileri DRAFT/schema1 bırakır. v2/RECORDED legacy write ve
replay409; RECORDED legacy single GET409. Eski SQL UPDATE için transaction-local
marker isteyen DB trigger vardır. Eski binary okuması güvenli rollback değildir;
gerçek kurulumda forward fix veya test edilmiş restore gerekir. 001 değiştirilmedi.

Tam teknik doğrulama:

- Backend: 129 PASS, 0 FAIL, 0 SKIP. Önceki 103 test ve 26 yeni test.
- Frontend: 74 PASS, 0 FAIL, 0 SKIP. Önceki 53 test ve 21 yeni test.
- Locked restore, .NET build (0 warning/error), TypeScript ve iki frontend build PASS.
- BFF + idari yolculuk: 390/768/1440 × TR/EN altı koşu PASS. Gerçek Chromium,
  React, ASP.NET OIDC/cookie/CSRF handler'ları ve PostgreSQL; sağlayıcı/anahtar/ticket
  test-only ephemeral. HTTPS/redirect taşınması Playwright–stdio–TestServer köprüsüdür.
- Mevcut legacy responsive/klavye matrisi: aynı altı görünüm PASS, draft POST yok.
- Yeni loopback sentetik UAT seeder gerçekten çalıştı: eksik DRAFT + IMO'suz RECORDED
  TUG üretti. İlk deneme ayrı Development DB'sinde 002 eksik olduğundan503 verdi;
  başarı sayılmadı. Mevcut Development migration yolu sonrası yeniden çalıştı.
- Gerçek eski şema fixture migration testi: vessel/certificate/audit/idempotency ve
  yetki/UUID korunması; eski UPDATE reddi. 601 kayıtlı gemide filtreli keyset turu,
  kopya/eksik olmaması; bilinmeyen geçmiş key/action redaksiyonu; issuer ayrımı;
  audit hatasında atomik rollback; concurrency/replay ve yetki iptali testleri PASS.

Bağımsız salt okunur incelemede üç P2 bulundu ve kapatıldı: JSON gövdesi beklerken
session invalidation; eksik tarihsel createdAt yerine update zamanını gösterme;
onaylanmış POST sonrası GET hatasında ikinci create riski. Sonuncusunda Operation
confirmedId saklar, tekrar yalnız GET yapar. Yeni test iki GET403 sonrası izin geri
gelince yalnız tek POST gerçekleştiğini doğrular. İnceleyen test çalıştırmadı;
buradaki PASS değerleri uygulama sahibinin gerçek son koşularıdır.

Kullanıcı UAT durumu: **PENDING**. Kullanıcının Android/web üzerinden açabildiği
owner-authenticated özel test URL'si **NOT_ESTABLISHED**. Localhost veya görev/Library
bağlantısı uygulamaya erişim kanıtı değildir. Paket teknik inceleme adayıdır;
U14 erişim kapısı kapanmadan kullanıcıya hazır/USER_ACCEPTED diye sunulamaz.

Native HTTPS, canlı IdP/federasyon/refresh/logout uyumu ve kurumsal key/ticket/
provisioning işletimi NOT_RUN/NOT_IMPLEMENTED. BFF hâlâ varsayılan kapalıdır.
Regülasyon, authoritative class/flag/subtype, IMO applicability/registry,
crew/master/DPA assignment, evidence verification, operasyonel readiness ve offline
ayrı modüllerdir. İdari envanter kaydı bunları onaylamaz; tam v46.3 ürün tamamlanmadı.

Teslim: complete source, taban patch, SHA-256 manifestleri, ADR, API eki, UAT adımları,
reproducible synthetic fixture ve sanitize edilmiş test kanıtları. Secrets, DB,
node_modules, bin/obj, screenshot ve gerçek kullanıcı verisi yoktur.

## Aynı Library dosyasında P2 düzeltmesi

Parent incelemesindeki çıkış/yazma yarışı ve belirsiz replay anahtarı kaybı kapatıldı.
API istemcisi ilk await öncesinde ortak logout/mutation rezervasyonu yapar; parent
logout busy ile child busy ayrıdır. Bekleyen çıkış sırasında handler/form submit dahil
hiçbir yeni inventory write başlamaz. Önceden başlamış yazı iptal edildi diye sunulmaz.
Belirsiz create, sonraki403 ile anahtarını kaybetmez; onaylı POST sonrası retry yalnız
GET olur. Ek bağımsız incelemede ilk yazı sırasında expiry belirsizliğinin doğru uyarıya
aktarılması da düzeltildi. İlgili incelemelerde açık somut bulgu kalmadı.

Yeni App testleri CSRF ve logout bekleme aşamalarında metadata/record/reopen için
sıfır yazı; ters sırada başlamış yazı varken logout reddi; concurrent session expiry
sonrası olası commit uyarısını denetler. Gerçek Chromium + gerçek PostgreSQL altı
viewport/dil koşusunda kontrollü commit sonrası yanıt kaybı → yetki iptali403 → yetki
geri gelişi aynı anahtarla tek nesne/tek event verdi. Deferred logout sırasında
zorlanmış form submit de sıfır yeni yazı verdi. Son tam backend129, frontend74,
BFF altı ve legacy responsive altı koşu PASS; sıfır skip/fail. Native TLS/gerçek IdP
ve kullanıcı private access/UAT sınırları değişmedi. Yayın yapılmadı.
