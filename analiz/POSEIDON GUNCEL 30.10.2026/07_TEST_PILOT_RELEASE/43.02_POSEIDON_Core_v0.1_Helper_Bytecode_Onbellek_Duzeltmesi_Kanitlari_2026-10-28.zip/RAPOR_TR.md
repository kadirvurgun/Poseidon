# Helper bytecode / temiz kaynak düzeltmesi

Taban e374d84d817cad5101d817cf9a8e80addc12958d. Eski helper'ın yalnız import
çalıştırılması temiz Git fixture'ında scripts/__pycache__ üretti ve gerçek
porcelain guard'ını engelledi. Bu owner gözlemiyle aynı sınıfta tekrar üretimdir.

Helper diagnostic source'u doğrudan compile/exec ile yükler; bytecode cache
oluşturmaz ve mevcut cache'i okumaz. Ignore yalnız mevcut helper cache'inin
/scripts/__pycache__/uat-diagnose.cpython-*.pyc pattern'idir. Guard değişmedi;
tracked/untracked anlamlı kaynak hâlâ reddedilir. Hiçbir dosya silinmedi.

76 test PASS. Gerçek helper subprocess, gerçek git status, mevcut cache,
hostile geçerli header cache'inin çalışmaması ve genuine edit ret testleri var.
Bu tur DB başlatma/durdurma çağrısı yok; kullanıcı runtime'ına dokunulmadı.
İnceleme/yayın sonrası pull ve temiz status doğrulaması; reset/clean/cache silme
veya stop-helper'ı yeniden çağırma gerekmez. Başka değişiklik varsa korunur.

138 tam kaynak, e374 patch, hashes ve kanıt dahil. Backend/frontend/browser
bu dar değişiklikte NOT_RERUN; lifecycle/auth guard değişmedi. İlk tarihsel PID
mismatch nedeni hâlâ açıklanmış sayılmaz. No push/commit/deploy veya secrets.
