# Poseidon İSG — Denizcilik Yazılımlarında İş İzni / Risk Değerlendirme Karşılaştırması

Erişim tarihi: **29.10.2026**. Kaynaklar tedarikçilerin kendi kamuya açık yayınlarıdır. Ürünler satın alınmadı, demo yapılmadı; alan düzeyinde test veya hukuk uygunluk doğrulaması yoktur. Pazarlama beyanı, gerçek kurulum kapsamı veya güvenlik garantisi değildir. Eski belgeler özellikle tarihlendirilmiştir.

## Kısa sonuç

Kullanıcının saptadığı boşluk, denizcilik filo yazılımı kıyaslamasında anlamlıdır: risk değerlendirmesi ve iş izinleri, yalnız belge eki değil bağlantılı HSEQ iş akışları olarak sunulmaktadır. Poseidon için önerilen model **risk değerlendirmesi → işe özel JSA → bir veya birden fazla ilgili izin → saha doğrulamaları → yetkilendirme → askı/yeniden değerlendirme → kapanış** olmalıdır. Bu ürün çıkarımıdır; rakiplerin bütün bu adımları aynı biçimde uyguladığı iddiası değildir.

| Tedarikçi / ürün | Kamuya açık doğrulanmış beyan | Poseidon'a çıkarım | Kanıt sınırı |
|---|---|---|---|
| **MariApps PALng / smartPAL** | Güncel PALng HSEQ sayfası risk değerlendirme iş akışları ve iş izni yönetimini açıkça sayıyor; olay, denetim ve düzeltici faaliyetlerin bağlantılı süreçler olduğunu anlatıyor. | İSG altında RA/PTW'yi görünür ayrı girişler olarak sun; ortak gemi/iş emri verileri ve takip bağlantıları kullan. | Ayrıntılı onay matrisi, izin süre kuralları, offline/self-hosted yetenekleri bu HSEQ beyanından doğrulanamaz. |
| **BASSnet** | Resmi 2023 broşürünün Risk Management bölümünde RA ana şablonları, gemi/ofis ad hoc formları, kontrol tedbirleri ve iş izni oluşturma/gönderme/düzenleme anlatılıyor. 17.11.2020 tarihli 2.11 duyurusu RA'nın PTW, iş emri ve planlı iş bağlantılarını; bir RA'ya çoklu izin bağlanmasını açıkça açıklıyor. | Veri modeli bir RA ↔ birden fazla izin ilişkisini ve bakım iş emri bağlantısını desteklemeli; şablon ile fiili değerlendirme kaydı ayrılmalı. | Tarihsel resmi kanıt; bugün her lisans/sürümde aynen bulunduğu test edilmedi. |
| **DNV ShipManager QHSE** | Güncel hizmet sayfası güvenlik dokümanları, denetimler, olaylar, tatbikat ve filo raporlarını sayıyor. Eski DNV GL markalı resmi broşür s.16 RA şablonlarının filo dağıtımını ve risk/iş izinlerini izlemeyi açıkça içeriyor. | RA/PTW doküman yönetimi, olay/düzeltici faaliyet ve filo görünümüyle ilişkilendirilmeli; sadece tek gemi formu olarak bırakılmamalı. | PTW ayrıntısı tarihli/eski broşür kanıtıdır; güncel sayfada aynı ayrıntının olmaması özelliğin kaldırıldığı veya sürdüğü sonucunu tek başına vermez. |

## Önceliklendirilmiş ürün kapsamı

**P0:** RA ve PTW listeleri, gemi/mahal/ekipman/iş emri bağlantısı, değişmez onaylı risk revizyonu, süre ve yetkili onayı, askı/iptal/kapanış, ekler ve audit trail. Prototipte örnekler operasyonel olmayan DEMO kaydı olarak etiketlenmeli.

**P1:** Filo şablon kütüphanesi, izin ailesine özgü önkoşullar, izolasyon kaydı bağlantısı, toolbox görüşmesi, SIMOPS/çakışma kontrolü, görev ve yetkinlik kontrolü, çoklu izin/RA ilişkisi, TR/EN aynı kayıt kimliği.

**P2:** Yönetim panoları, geçmiş olaylardan öğrenme bağlantısı, trendler, filo bazlı şablon revizyon dağıtımı, kontrollü offline senkronizasyon. Hiçbir analitik “iş güvenli” veya “başlama izni verildi” kararını insan yetkilendirmesinin yerine üretmemeli.

**Kopyalanmayacak şeyler:** Rakip ekran tasarımının birebir kopyası, mülkiyetli risk kütüphaneleri/form içerikleri, “tüm mevzuata uyum garantisi” veya doğrulanmamış self-hosted/AI/offline vaatleri. Yeni alanlar Poseidon veri modeline ve geminin onaylı SMS'ine göre tasarlanmalı.

## Kaynak sicili

1. **MariApps PALng — HSEQ, güncel resmi ürün sayfası:** https://www.mariapps.com/palng/ — 29.10.2026 doğrudan açıldı; HSEQ bölümünde RA workflows/work permit management. Ekrandaki örnek tarihler ve sayaçlar gerçek müşteri/filo ölçümü kabul edilmedi.
2. **MariApps, 2023 World Day for Safety and Health at Work:** https://www.mariapps.com/maritime-safety-health-day/ — tarihsel smartPAL beyanında Risk Assessments, Work Permits, Management of Change ayrı işlevler olarak listeleniyor; RA kütüphanesi belirtiliyor.
3. **BASS Brochure 2023, s.42–43 Risk Management:** https://www.bassnet.no/wp-content/uploads/2024/01/BASS-Brochure-2023-20122023_1.pdf — resmi indekslenmiş PDF metniyle doğrulandı; web PDF okuyucu boyut sınırına takıldı.
4. **BASSnet 2.11 Preview, 17.11.2020:** https://www.bassnet.no/insight/bassnet-2-11-preview/ — doğrudan açıldı; HSEQ & Operations bölümü, RA/PTW/job ilişkileri. Bugünkü sürümün adı olduğu iddia edilmez.
5. **DNV ShipManager QHSE güncel hizmet sayfası:** https://www.dnv.com/services/ship-safety-management-system-shipmanager-qhse-1534/ — resmi kamu sayfası; genel QHSE işlevleri.
6. **DNV GL ShipManager and Navigator broşürü, s.16:** https://www.dnv.com/siteassets/images/pdf-documents/maritime-software---shipmanager---navigator---brochure.pdf — eski markalı tarihsel ürün kanıtı, resmi indekslenmiş metin incelendi; web PDF okuyucu boyut sınırına takıldı.

## Açık doğrulamalar

Tedarikçi demosuyla test edilmeden tam süreç uyumu, teknik dağıtım modeli, entegre e-imza, rol ayrımı, ölçüm doğruluğu kontrolü, kapalı alan yeni IMO referansına güncelleme ve audit değişmezliği hakkında hüküm verilmez. Rakip karşılaştırması ürün boşluğunu destekler; hangi işlemin hangi gemide yasal olarak zorunlu olduğunu belirleyen kanıt değildir. Yasal kapsam için `hse_regulatory_research.md` esas alınmalıdır.
