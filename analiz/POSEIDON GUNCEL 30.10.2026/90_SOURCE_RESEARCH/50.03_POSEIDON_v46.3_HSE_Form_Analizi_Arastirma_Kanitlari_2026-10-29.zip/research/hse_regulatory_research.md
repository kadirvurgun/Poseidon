# Poseidon İSG — İş İzinleri ve Risk Değerlendirmesi

**Araştırma ve erişim tarihi: 29.10.2026.** Kapsam: gemi/römorkör filo ürününde eksik bulunan Permit to Work (PTW) ve risk değerlendirme iş akışlarının analizi. Bu belge yazılım gereksinimi önerisidir; bir işe başlama izni, kapalı alana giriş talimatı, uzman risk değerlendirmesi veya hukuki uygunluk belgesi değildir. Üretim değişikliği yapılmamıştır.

## 1. Kritik kararlar

1. İSG altında **İş İzinleri** ve **Risk Değerlendirmeleri** ayrı modül/sekme olmalı; iş emri, gemi, mahal ve ekipman üzerinden birbirine bağlanmalıdır. Bir PDF yükleme alanı bu eksikliği tek başına kapatmaz.
2. İşyeri/gemi temel risk değerlendirmesi, iş bazlı JSA/JHA ve sahada değişen koşullara yönelik dinamik değerlendirme aynı kayıt değildir. Birinin onayı diğerini otomatik onaylamamalı.
3. Yazılım yalnız yetkili kişilerin kararlarını, önkoşul doğrulamalarını ve kayıtlarını destekler. Risk puanı düşük çıktı diye otomatik izin açılmaz. İnsan onayları veya sahadaki doğrulama yerine AI kararı kullanılmaz.
4. Kapalı alanlarda güncel referans **MSC.581(110), 27 Haziran 2025** olmalı; yalnız A.1050(27) üzerine kurulmuş form güncellik incelemesine alınmalıdır. IMO tavsiyesi, SOLAS'ın bağlayıcı hükümleri ve bayrak/SMS uygulaması ayrı işaretlenir. [H1]
5. ILO'nun güncel resmi listesinde Türkiye, **MLC 2006'yı onaylamamış** ülkeler arasındadır. Bu nedenle “MLC bütün Türk bayraklı römorkörler için onaylanmış sözleşme olarak zorunlu” denemez. [H5]

## 2. Yasal dayanak ve kapsam

### ISM / SOLAS

IMO'nun ISM açıklaması gemi, insan ve çevre için belirlenen risklerin değerlendirilmesini ve uygun koruyucu tedbirleri genel amaçlar arasında sayar; bu yaklaşım ISM 1.2.2.2 ile ilişkilidir. Kod güvenli işletme ve kirliliğin önlenmesi için yönetim sistemi temelidir. [H2] Uluslararası sefer yapan yolcu gemileri ve 500 GT ve üstü ilgili yük gemisi/MODU grupları için SOLAS IX kapsamı önemlidir; ulusal uygulama daha geniş olabilir. Dolayısıyla küçük, yalnız limanda çalışan bir römorkörün her durumda uluslararası ISM kapsamına girdiği veya bütün İSG yükümlülüklerinden muaf olduğu söylenemez. [H3]

Üründe `flag_administration`, `gross_tonnage`, `tonnage_basis`, `voyage_scope`, `operating_area`, `ship_regulatory_class`, `commercial_use`, `employer`, `contractor`, `applicable_instruments[]` ve `sms_revision` bulunmalıdır. Bir izin türünün kaynağı `statutory / flag_instruction / port_terminal / company_sms / recommended_practice` olarak ayrılmalı; zorunluluk yalnız “gemi tipi = tug” koşulundan türetilmemelidir.

### Kapalı alan: güncel IMO tavsiyesi

MSC.581(110), §5 ve Ek 2; risk bulunan girişlerde izin sistemi, kaptan/atanmış sorumlu yetkilendirmesi, risk değerlendirmesine göre **sekiz saati aşmayan** süre ve faaliyet gerektirdiğinde ek izinler öngören tavsiyeler sunar. Örnek izin; havalandırma durması veya kontrol koşullarının değişmesiyle geçersizleşir; alan terk edilip gözetimsiz bırakılırsa yeniden inceleme gerekir. Ek enerji/elektrik izolasyonu, sıcak iş veya yüksekte çalışma izni gerekebilir. Kararın giriş kısmı SOLAS III/19.3.6 tatbikat ve XI-1/7 ölçüm cihazı yükümlülüklerini ayrıca anmaktadır. Bunları aynı hukuki kuvvette tek listeye çevirmeyin. [H1]

Hong Kong Denizcilik İdaresi'nin 68/2025 duyurusu eski A.1050(27)'nin kaldırıldığını bildirir. Bu rapor, farklı ikincil kaynaklarda görülen yürürlük günü yorumlarını evrensel bağlayıcılık tarihi olarak kullanmaz. [H4] Gemiye özgü uygulama ve otorite talimatı kontrol edilmelidir. Gaz eşikleri veya ölçüm prosedürü burada operasyonel talimat olarak verilmemiştir; yetkili uzman tarafından güncel resmi kaynakla yönetilmelidir.

### ILO MLC

MLC A4.3; bayrak devleti uygulamasında iş sağlığı ve güvenliği programları, risk değerlendirmesi, eğitim ve kazaların önlenmesini kapsar. [H6] MLC'nin temel gemi kapsamı ile 500 GT/uluslararası sefer sertifikalandırma eşiği aynı şey değildir. Ticari kullanım, iç/korunaklı sular, balıkçılık ve savaş gemisi istisnaları ile yetkili idarenin belirlemeleri değerlendirilmelidir. [H7] Türkiye için onay durumu yukarıdaki gibidir; yabancı bayrak ve yabancı liman denetimi ayrıca ele alınmalıdır. 2025 MLC değişikliklerini bugünkü hukuk gibi etiketlemeyin: ILO kaydı bunları henüz yürürlükte değil, beklenen yürürlük 23.12.2027 olarak gösterir. [H8]

### Türkiye: 6331 ve Risk Değerlendirmesi Yönetmeliği

6331 madde 2 işyerleri/çalışanlar için geniş kapsam ve sayılı istisnalar içerir; resmi metinde deniz taşıması için genel bir istisna yoktur. Madde 3 çalışanı özel kanun statülerinden bağımsız tanımlar. Bu nedenle 4857'deki deniz taşımacılığı istisnasını 6331'e otomatik taşımak yanlış olur. Ancak yabancı bayrak, uygulanacak hukuk, işveren/çalışan ilişkisi, faaliyet yeri ve 854 Deniz İş Kanunu bağlamı ayrıca uzman incelemesi gerektirir; “her bayrakta her faaliyet için 6331 kesin uygulanır” sonucu da çıkarılamaz. [H9]

Yönetmelik 6331 kapsamındaki işyerleri için ekip çalışması ve risk değerlendirmesini düzenler. Bakanlık SSS'si ekip ve asıl işveren-alt işveren koordinasyonunu açıklar; tek bir zorunlu puanlama yöntemi dayatılmadığını belirtir. [H10] Madde 11 dokümantasyonda işyeri, hazırlayanlar ve yeterlikleri, tarih/geçerlilik, tehlike/risk, yöntem, analiz ve kontrol sonrası risk kayıtlarını ister; elektronik hazırlama/arşivlemeye izin verir. Madde 12'nin çok tehlikeli/tehlikeli/az tehlikeli için 2/4/6 yıllık azami yenilemeleri **iş izni süresi değildir**; değişiklik/olay tetiklemeli yenileme ayrıca vardır. İmza ve saklama koşulları hukuk incelemesiyle elektronik iş akışına çevrilmelidir. [H11]

Bakanlık ayrıca yayımlanan kontrol listelerinin risk değerlendirmesinin yerine geçmediğini açıklar. Hazır şablonun doldurulması tek başına işveren sorumluluğunu kaldırmaz. [H12]

### COSWP 2026: karşılaştırmalı iyi uygulama

MCA'nın güncel baskısı 2026'dır; UK bayraklı ticaret gemilerindeki taşıma yükümlülüğü UK'ye özgüdür. [H13] Bölüm 14 izin veren yetkili ile işi yapan yetkin kişiyi ayırır; konum, iş, testler, önlemler, süre, devir ve kapatma kayıtlarını işler. Genel izin süresini 24 saati aşmama yönünde ele alması, IMO kapalı alan sekiz saat tavsiyesiyle tek varsayılan süre yapılmamalıdır. Güncel PDF'nin Bölüm 14, s.185–187 bölümü doğrudan incelendi. [H14]

## 3. Önerilen veri nesneleri — ürün tasarımı

Aşağıdaki liste kaynaklardan alınmış zorunlu evrensel form değil, Poseidon için önerilen veri modelidir.

### A. Temel risk değerlendirmesi / Baseline risk assessment

- Gemi/işyeri, işveren, departman/mahal, faaliyet kapsamı; düzenleme profili ve geçerlilik gerekçesi.
- Değerlendirme ekibi, rol ve yeterlik referansları; çalışan katılımı ve gözden geçiren kişi.
- Tehlike kaynağı, etkilenebilecek kişiler, olay/sonuç, mevcut kontrol, seçilen analiz yöntemi ve sürümü.
- İlk risk, önerilen önlem, önlemin sahibi ve hedef tarihi, gerçekleşme kanıtı, kalan risk, insan kabul kararı.
- Onaylanan revizyon, gözden geçirme tarihi, değişiklik/olay tetikleyicisi, kaynak dokümanlar ve audit trail.

Bir 5×5 matris kullanılacaksa olasılık/şiddet tanımları ve kabul sınırları uzman onaylı şema olarak sürümlenmeli; yasal tek yöntem olduğu iddia edilmemeli. Eksik bilgi sıfır risk değildir.

### B. İş bazlı değerlendirme / JSA–JHA–Task risk assessment

İş emri + gemi/ekipman + kesin iş kapsamı + iş adımları + işe özel tehlikeler + eşzamanlı işler + mevcut durum + kontroller + sorumlular + kalan risk + değerlendirme ekibi + toolbox görüşmesi + katılımcı teyitleri. Referans temel değerlendirme **ID ve revizyonuyla** bağlanır. Şablon kopyası yeni işte yeniden doğrulanmadan onaylı olmaz.

### C. Dinamik saha değerlendirmesi / Dynamic assessment

İş öncesi/sırasındaki gözlem, değişen koşul, gözlemci, zaman, durdurma gerekçesi, yeni önlemler ve yeniden değerlendirme kararı. Bu kısa kayıt; formal risk değerlendirmesini veya izin revizyonunu ikame etmez. Yeni ciddi risk ortaya çıktığında yazılım “devam” varsaymamalı, ilgili yetkiliye inceleme gereksinimi göstermelidir.

### D. İş izni / Permit to Work

| Alan grubu | Önerilen kayıtlar |
|---|---|
| Kimlik | İzin no, gemi, şirket, mahal ID, ekipman ID, iş emri, izin türleri |
| İş sınırı | Kesin iş tarifi, izin dışı işler, ekip/taşeron, eşzamanlı iş bağlantıları |
| Dayanak | JSA ve temel risk revizyonu; SMS prosedür/şablon sürümü; liman/terminal onay referansları |
| Zaman | Planlanan süre, fiili başlama, geçerli başlangıç/bitiş; UTC ve gemi yerel saat ofseti; vardiya |
| Hazırlık | Yetkili saha kontrolü, izolasyon sertifikaları, kontrol kanıtı, uygun ekipman/yeterlik, toolbox teyidi |
| Ölçüm | Gerektiğinde cihaz kimliği, doğrulama/kalibrasyon referansı, ölçen kişi, konum/zaman, birim ve sonuç; uzman onaylı sınır profili |
| Acil hazırlık | Gemi onaylı acil plan referansı, iletişim, gözcü/kurtarma rolü ve hazırlık teyidi |
| Onay | Talep eden, inceleyen, izin veren, işi teslim alan, rol/yetki kapsamı, imza zamanları |
| Yaşam döngüsü | Askı nedeni/zamanı, iptal, süre sonu, devir, yeniden doğrulama, kapanış ve ekipman teslimi |

Önerilen ilk şablon aileleri: **sıcak iş, kapalı alana giriş, yüksekte çalışma, borda dışı çalışma, enerji izolasyonu/LOTO, elektrik işleri veya test yetkisi**. Faaliyet/filo ihtiyacına göre kaldırma, dalış ve basınçlı hat açma şablonları ayrıca değerlendirilir; bu listenin her maddesi her gemide yasal olarak aynı biçimde zorunlu değildir. Test yetkisi ile bakım/onarım izninin amaçları ayrılmalıdır.

## 4. Önerilen akış ve emniyet sınırları

`Taslak → İncelemede → Hazırlık doğrulaması bekliyor → Yetkilendirildi → Aktif → İş tamamlandı / teslim bekliyor → Kapalı`

Yan durumlar: `Reddedildi`, `Askıda`, `İptal`, `Süresi doldu`, `Yeniden değerlendirme gerekli`. “Yetkilendirildi” planlanan başlangıçtan önce çalışılabileceği anlamına gelmez. “İş tamamlandı” izolasyonların kaldırıldığı veya ekipmanın servise verildiği anlamına gelmez.

Önerilen backend kuralları:
- Eksik/eskimiş iş riski, gerekli rol/yeterlik, kontrol kanıtı veya onay varsa aktivasyon engellenir. Bir admin onayı güvenlik uzmanı/kaptan yetkisi yerine geçmez.
- Aynı ekipman/mahal için çelişkili izinler ve SIMOPS uyarısı; ilgili izinler karşılıklı bağlıdır.
- Süre dolduğunda izin otomatik geçerli kalmaz; e-posta okunmasa da backend geçerlilik denetlenir.
- Kapsam, ekip, vardiya, mahal koşulu, izolasyon, ölçüm veya risk revizyonu değiştiğinde etki incelemesi. Önemli değişiklikte eski izin üstüne yazma değil yeni revizyon/yeniden yetkilendirme.
- Askıdan çıkış tek “resume” düğmesiyle olmaz: gerekli yeniden kontroller ve yetkili kabulü. İlgili kapalı alan profilinde geçersizleşme hâli yeni izin sürecini gerektiriyorsa bunu koru.
- Sahadaki ekip işi durdurmayı bildirebilir; yeniden başlatma yetkisi aynı geniş gruba verilmez.
- Acil durumda alarm ve geminin yetkili acil müdahale planına erişim kolay olmalı; form tamamlama bekletilmemeli. Yazılım kendiliğinden kurtarma talimatı veya tehlikeli alana giriş yetkisi üretmemeli.
- Kapanışta personel/alet kontrolü, mahalın emniyete alınması, sorumlu vardiya bilgilendirmesi ve ekipmanın teslim durumu kaydedilir; izolasyon kaldırma ayrı yetkili süreçtir.

## 5. Self-hosted uygulama, prototip ve kabul testleri

Şablonlar TR/EN, sürümlü ve yetkili onaylı olmalı. Onaylanan sürüm değişmez; sonraki değişiklik yeni sürümdür. Klinik sağlık verileri iş iznine kopyalanmamalı; gerektiği kadar yetkinlik/uygunluk doğrulaması gösterilmeli. Rol tabanlı erişim, saklama politikası ve imza hukukiliği ayrıca onaylanır.

Offline senaryoda: yerel saat/saat sapması, belge son senkronizasyonu ve çakışan düzenlemeler görünür; senkronize edilmemiş izin sunucuda otomatik aktif kabul edilmez. Geminin onaylı kâğıt/yerel devamlılık prosedürünün kayıt bağlantısı kurulabilir; bağlantı kesintisi kontrolleri atlama yetkisi değildir.

Prototipte önerilen ekranlar: açık izin panosu (mahal/ekipman/sona erme), izin sihirbazı, risk kayıt defteri, JSA hazırlama, kontrol/ölçüm günlüğü, izolasyon bağlantıları, yetkilendirme, askı/yeniden doğrulama, kapanış ve değişmez denetim geçmişi. Örnekler **DEMO — operasyonel izin değildir** olarak işaretlenmelidir.

Asgari testler: süresi geçmiş izin aktive edilemez; görev yetkisi olmayan kullanıcı onaylayamaz; ilişkili risk revizyonu değişince uyarı çıkar; kapalı alan için ilgili süre profili uygulanır; kritik koşul değişimi askı/geçersizlik üretir; kapatma izolasyonu otomatik kaldırmaz; TR/EN aynı ID ve anlamı taşır; geçmiş belge yeni şablondan sessizce yeniden yazılmaz; audit kaydı ve offline çakışma korunur.

## 6. Kaynaklar ve doğrulama sınırları

Tüm erişimler **29.10.2026**. Kısa özetler; tam standart metinler veya ticari formlar yeniden dağıtılmamıştır.

- **H1 IMO MSC.581(110), §5, Ek 2:** https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.581%28110%29.pdf
- **H2 IMO ISM açıklaması:** https://www.imo.org/en/ourwork/humanelement/pages/ismcode.aspx
- **H3 Transport Canada ISM kapsamı:** https://tc.canada.ca/en/marine-transportation/marine-safety/international-safety-management-ism-code
- **H4 Hong Kong Marine Department 68/2025, 02.12.2025:** https://www.mardep.gov.hk/filemanager/en/share/msnote/pdf/msin2568.pdf
- **H5 ILO NORMLEX, Türkiye'nin onaylamadığı sözleşmeler:** https://wwwex.ilo.org/dyn/f?p=NORMLEXPUB%3A11210%3A0%3A%3ANO%3A%3AP11210_COUNTRY_ID%3A102893
- **H6 ILO MLC A4.3:** https://www.ilo.org/dyn/normlex/en/f?p=NORMLEXPUB%3A91%3A0%3A%3A%3A%3AP91_SECTION%3AMLCA_AMEND_A4
- **H7 ILO MLC metni / Article II ve sertifikalandırma:** https://normlex.ilo.org/dyn/nrmlx_en/f?p=NORMLEXPUB%3A12100%3A0%3A%3ANO%3A%3AP12100_ILO_CODE%3AMLC ; https://wwwex.ilo.org/dyn/f?p=NORMLEXPUB%3A92%3A0%3A%3ANO%3A%3AP92_SECTION%3AMLC_A5 ; bayrak otoritesi uygulama açıklaması: https://normlex.ilo.org/dyn/nrmlx_en/f?p=1000%3A53%3A%3A%3A%3A53%3AP53_FILE_ID%3A3280257
- **H8 ILO MLC 2025 değişikliklerinin durumu:** https://wwwex.ilo.org/dyn/f?p=NORMLEXPUB%3A11301%3A0%3A%3ANO%3A%3AP11301_INSTRUMENT_AMENDMENT_ID%3A4438362
- **H9 ÇSGB 6331 resmi metni, özellikle madde 2–4/10:** https://www.csgb.gov.tr/Media/hywpvejh/6331-say%C4%B1l%C4%B1-i%C5%9F-sa%C4%9Fl%C4%B1%C4%9F%C4%B1-ve-g%C3%BCvenli%C4%9Fi-kanunu.pdf
- **H10 ÇSGB SSS, risk değerlendirme ekibi, alt işveren, yöntem:** https://csgb.gov.tr/tr/sikca-sorulan-sorular/is-sagligi-ve-guvenligi-genel-mudurlugu/
- **H11 Risk Değerlendirmesi Yönetmeliği, resmi kamu yayını:** https://orhanelidh.saglik.gov.tr/TR-537813/is-sagligi-ve-guvenligi-risk-degerlendirmesi-yonetmeligi.html ; resmi kamu PDF kopyası: https://gediz.meb.gov.tr/meb_iys_dosyalar/2023_12/24094624_issagligiveguvenligiriskdegerlendirmesiyonetmeligi.pdf
- **H12 ÇSGB kontrol listesi açıklaması:** https://www.csgb.gov.tr/isggm/yayinlar-ve-afisler/
- **H13 MCA güncel COSWP 2026 yayın sayfası:** https://www.gov.uk/government/publications/code-of-safe-working-practices-for-merchant-seafarers-2026-edition
- **H14 MCA COSWP 2026, Bölüm 14 s.185–187:** https://assets.publishing.service.gov.uk/media/69bd45a5ed813d0d8b690c2b/code-of-safe-working-practices-for-merchant-seafarers-2026-edition.pdf

MLC tam metin bazı çağrılarda redirect loop verdi; NORMLEX onaylanmayan sözleşmeler ve değişiklikler listesi arama sonucu üzerinden doğrulandı. COSWP PDF web okuyucusunun boyut sınırını aştı; resmi URL'den yerel indirme ve pdftotext ile güncel Bölüm 14 incelendi. Eski 2020–2022 form sonuçları güncel referans olarak kullanılmadı. Türk düzenlemelerinin tüm değişiklik/konsolidasyon geçmişi ve gemiye özgü hukuk incelemesi tamamlanmış değildir. İzin şablonlarının üretime alınması için denizcilik/İSG yetkilisi, şirket SMS sahibi ve gerekiyorsa bayrak idaresi değerlendirmesi gereklidir.
