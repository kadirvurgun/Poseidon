# Poseidon — rakip kanıt incelemesi: Bayrak ve Gemi Tipi

**Erişim tarihi:** 29 Ekim 2026 (UTC). **Kapsam:** gemi ve römorkör filo yönetimi; liman yazılımı veya kara taşıtı filosu değil. Dört denizcilik ürünü: BASSnet, MariApps smartPAL, DNV ShipManager, SpecTec AMOS/AMOS-X.

## Sonuç

Serbest metin yerine yönetilen referans değer seçimi güçlü bir tasarım yönüdür: BASSnet'in kamuya açık yardımında hem Bayrak hem Gemi Tipi lookup olarak belgelenmiştir. smartPAL ise modüller arasında paylaşılan merkezi master-data yaklaşımını açıkça tanımlar. Ancak incelenen kaynaklar bütün rakiplerin aynı filtre/form kataloğunu, Türkçe aramayı, klavye etkileşimlerini veya tarihçeli bayrak değişimini desteklediğini kanıtlamaz. Bunlar aşağıda **Poseidon'a özgü öneri** olarak ayrılmıştır; rakip yeteneği veya hukuki zorunluluk olarak sunulmaz.

## Yöntem ve kanıt seviyeleri

- **A — doğrudan dokümantasyon:** resmi, açık yardım sayfasında alan veya işlem tarif edilir. Çalışan üründe test edildiği anlamına gelmez.
- **B — resmi ürün/hizmet beyanı:** satıcının kamuya açık sayfası işlevi söyler; alan düzeyindeki davranış, sürüm ve kullanıcı yetkileri doğrulanmış değildir.
- **Y — araştırmada doğrulanmadı:** incelenen kamu kaynakları bu ayrıntıyı göstermedi. Üründe yok demek değildir.
- Yalnızca birincil satıcı kaynakları kullanıldı. Oturum açılmadı, özel müşteri arayüzüne erişilmedi; ekran kopyalanmadı. Yardım belgelerinin sürümleri/güncellik tarihleri her yerde açık değildir. Web sayfası dili, ürünün çok dilli alan desteği sayılmadı.

## Kaynak ve bulgu tablosu

Tüm satırlar için erişim: **2026-10-29**.

| ID | Ürün / kaynak | Belgelenen özellik | Seviye | Poseidon'a ilgisi ve sınır |
|---|---|---|---|---|
| C01 | BASSnet HR Manager — [Vessel Particulars](https://cloud.bassnet.no/HRConnect/WebHelp/HR_Manager/Site/Particulars/Vessel_Particulars.htm) | Vessel Type lookup; seçilen tipe göre Vessel Type Group otomatik dolar. Flag ayrı lookup; Registry Port ayrı alandır. Vessel Code ve IMO ayrı tutulur. Inactive Vessel seçeneği vardır; bu ekranda gemi kaydı silinmez. | A | Doğrudan Bayrak/Gemi Tipi örneği. Lookup içi metin araması, seçenek kod standardı ve filtre ile aynı kaynak olduğu belgelenmiyor. İnaktif **gemi** ile inaktif **referans değeri** aynı şey değildir. |
| C02 | BASSnet CRM — [Vessel Type Register](https://cloud.bassnet.no/CRM/WebHelp/Administration/Register_Setup/Vessel_Type.htm) | Sistem genelinde tip kodu referansı; erişim hakkına bağlı düzenleme/silme. Kod, açıklama, kısaltma, grup açıklaması ve Active alanları; yönetim menüsünden kayıt ekleme/güncelleme. | A | Katalog yönetimi ve kod/etiket ayrımı için en güçlü örnek. HR ve CRM farklı dokümantasyon bağlamlarıdır; tek veritabanı şeması varsayılmaz. Kaynak girişte 3–4 karakter, alan açıklamasında 1–10 karakter der; bu çelişki Poseidon'a taşınmamalı. Silmenin mevcut bağlı kayıtları nasıl etkilediği açıklanmıyor. |
| C03 | MariApps smartPAL — [MDM](https://www.mariapps.com/mdm/) | Merkezi master-data havuzu; işlem ve analitik modüllerinde paylaşım; vessel register; register import/export; modül bazında düzenleme. | B | Ortak katalog mimarisini destekler. Bayrak/Gemi Tipi alan widget'ları, kod standardı, yetki matrisi ve filtre eşleşmesi bu sayfada yok. |
| C04 | MariApps smartPAL — [Data Library](https://www.mariapps.com/smartpal/data-library/) | Ekipman, iş ve yedek parça verilerinin merkezileştirilmesi; Excel toplu yükleme şablonları; gemiye bağlantı; tekrarları azaltma ve veri bütünlüğü beyanları. | B | Veri kalitesi ve kontrollü toplu aktarım örneği. Bu kapsam **teknik veridir**; bayrak/tip kataloğunda aynı import veya doğrulama mevcut diye genellenemez. |
| C05 | DNV — [ShipManager](https://www.dnv.com/services/marine-fleet-management-software-and-ship-management-systems-shipmanager-114260/) | Entegre PMS/procurement/QHSE modülleri; eski sistemlerden veri yakalama/migrasyon, filo ekipman sicili kurulumu ve eğitim hizmetleri. | B | Standardizasyonun yalnızca dropdown değil, geçiş ve işletim işi olduğunu destekler. Açık sayfa Bayrak/Gemi Tipi formunu veya referans yönetimini göstermiyor. |
| C06 | SpecTec — [AMOS-X](https://spectec.net/amos-x/) | Rol bazlı arayüz ve mobil iş akışları; varlık yapıları, bakım planları ve stok seviyeleri için merkezi filo yapılandırması; mevcut AMOS verisini koruyarak modüler geçiş beyanı. | B | Merkezden yönetim ve mobil kullanım yönü. Bayrak/tip alanlarına özgü davranış kanıtı değil; ürün performans yüzdeleri doğrulanmadığından tasarım gerekçesinde kullanılmadı. |
| C07 | SpecTec — [Data Migration Services](https://spectec.net/service/database-migration-services/) | Üçüncü taraf gemi yönetim veritabanlarından ve Excel'den AMOS'a geçiş; ofis/gemi senkronizasyon hizmeti. | B | Eski serbest metni eşleme ve kontrollü migrasyon gereğini destekleyen hizmet örneği. Otomatik bayrak/tip temizleme, eşleme veya tarihçe koruma algoritması belgelenmiyor. |

## İstenen boyutların karşılaştırması

| Boyut | BASSnet | smartPAL | ShipManager | AMOS/AMOS-X |
|---|---|---|---|---|
| Bayrak ve tip için kontrollü seçim | A: ikisi lookup (C01) | Y | Y | Y |
| Seçenek içinde metin arama | Y; lookup, searchable combobox ile eşit değildir | Y | Y | Y |
| Kod, açıklama, kategori | A: tip register (C02) | Y: alan ayrıntısı yok | Y | Y |
| Form ve filtre aynı katalog | Y; C02 sistem geneli referans der ama filtre eşleşmesi göstermez | B: modüller arası ortak master-data; form/filtre özelinde Y | Y | Y |
| Çok dilli etiket / TR karakter normalizasyonu | Y | Y | Y | Y |
| Veri kalitesi | A: referans seçimi; tam veri kalite kuralı Y | B: merkezileştirme/tekrar azaltma (C04) | B: veri/migrasyon hizmeti (C05) | B: merkezi yapı ve migrasyon (C06–07) |
| Master-data yönetimi | A: tip register ve erişim hakkı (C02) | B: MDM (C03) | Y: bu alanlara özgü | B: teknik filo yapılandırması; bayrak/tip özelinde Y |
| İnaktif referans değeri | A: tip Active alanı (C02); eski kayıtta gösterim davranışı Y | Y | Y | Y |
| Bayrak/tip değişiklik tarihçesi | Y | Y | Y | Y |
| Özel alanlar | Y: incelenen belgelerde bu iki alan için yok | Y | Y | Y: yapılandırılabilirlik custom-field kanıtı sayılmaz |
| Migrasyon | C02: uygulama aşamasında tip kodları tanımlanır; veri migrasyonu Y | B: register import/export (C03) | B: hizmet (C05) | B: hizmet ve ürün geçişi (C06–07) |
| Mobil ve klavye | Y | Y: bu araştırmanın kaynakları alan davranışı vermiyor | Y | B: mobil iş akışı; klavye/combobox davranışı Y |

## Poseidon için özgün standardizasyon kararları

Bu bölüm rakip arayüzünün kopyası değil, kaynak bulgularından ve Poseidon'un gemi/römorkör kapsamından geliştirilen **ürün önerisidir**. Nihai yasal kapsam ve kod listeleri ayrı mevzuat incelemesiyle belirlenmelidir.

1. **Tek katalog, çok kullanım:** `flag_state_id` ve `vessel_type_id` kalıcı kimlikleri saklansın; Türkçe/İngilizce görünen etiketler kayıt anahtarı olmasın. Oluşturma, düzenleme, liste filtresi, import ve API aynı katalog servisinden beslensin. Filtre seçimleri farklı/elle yazılmış liste kullanmasın.
2. **Bayrak ≠ sicil limanı ≠ işletmeci ülkesi:** ayrı veri alanları ve yardım metinleri kullanılsın. Bayrak devleti kaydı yalnız ülke ikonuyla gösterilmesin; ad ve kod metin olarak yer alsın. Hangi referans kod sisteminin kullanılacağı resmi standardın lisans/kapsam koşullarıyla ayrıca onaylansın.
3. **Tip sınıflandırması:** ana tip, alt tip, operasyonel rol ve dış raporlama eşlemesi ayrılmalı. Römorkör ana tipini, örneğin liman destek göreviyle veya sevk konfigürasyonuyla tek düz dropdown içinde karıştırmayın. İç tip kodunun AIS/IMO veya başka dış raporlama koduna bire bir eşit olduğu varsayılmasın; sürümlü mapping tablosu kullanılsın.
4. **Seçim UX:** erişilebilir, aramalı combobox; ad, kod ve onaylı eşanlamlılarla arama. TR/EN adları ve `Türkiye/Turkey`, `römorkör/romorkor/tug` gibi kontrollü alias'lar eşleşsin. `I/İ/ı/i` testleri açıkça yazılsın. Çoklu seçim yalnız filtrelerde; gemi formunda tek geçerli değer. Sonuç yokken serbest metni otomatik kataloğa eklemeyin; inceleme isteği açın.
5. **Belirsiz değerler:** bilinmiyor, eksik, doğrulama bekliyor ve gerçek tip `Diğer` birbirinden ayrılmalı. `Diğer` seçimi açıklama ve yönetici incelemesi gerektirsin; hukuki raporlama karşılığıymış gibi otomatik kodlanmasın. Bilinmeyen eski değer sessizce bir kategoriye atanmasın.
6. **Tarihçe ve pasifleştirme:** kullanılan değer hard-delete edilmesin. Yeni seçimde pasif değer gizlenebilir; mevcut kayıtta ve tarihsel filtrede görünür, pasif etiketiyle korunmalı. Bayrak/tip değişiminde eski/yeni kimlik, yürürlük tarihi, kayıt zamanı, kullanıcı, gerekçe ve dayanak tutulmalı; eski rapor yeni etiketle sessizce yeniden anlamlandırılmamalı.
7. **Yönetim:** katalog yöneticisi düzenler; normal kullanıcı seçim yapar. Kod değişimi, birleştirme ve dış kod eşlemesi ayrı yetki/onay gerektirsin. Tip katalog sürümü ve kaynak tarihi kaydedilsin. Yeni değer ile ad düzeltmesi ayrı işlemler olsun.
8. **Migrasyon:** ham değerleri koruyun; normalize edilmiş aday, önerilen kimlik, güven düzeyi, onaylayan ve eşleme kararını saklayın. Otomatik eşleşme sadece kesin/onaylı alias için olsun. Tekrarlı, belirsiz, boş ve geçersiz değerler istisna kuyruğuna alınsın; dry-run, geri alma, önce/sonra adetleri ve örneklem doğrulaması yapılsın.
9. **Mobil/klavye:** dokunma hedefleri ve uzun listeler küçük ekranda test edilsin; ekran klavyesi seçenekleri kapatmasın. Tab, ok tuşları, Enter ve Escape; ekran okuyucu etiketleri; seçimi temizleme ve hata odağı testleri kabul kriteri olsun. Bunlar rakipte gözlenmiş özellik değil, Poseidon kalite hedefidir.

## Uygulama öncesi kapatılacak kanıt boşlukları

- Mevcut Poseidon verisinin ve form/filtrelerin gerçek örnekleri: alanların serbest metin oranı, mevcut kodlar, boşlar ve birden çok anlam taşıyan değerler.
- Yetkili ürün demosu veya satıcı yanıtıyla istenirse doğrulanabilecek konular: tarihçeli bayrak değişimi, inaktif değer davranışı, çeviri/alias, klavye erişilebilirliği, offline seçim ve çakışma çözümü.
- Bayrak ve gemi tipinden mevzuat otomatik çıkarılmamalı: tonaj, boy, sefer kapsamı, işletim, inşa tarihi, sertifikalar ve istisnalar gibi ek kapsam alanları hukuk çalışmasında değerlendirilmelidir.
- Rakip destek durumu hakkında olumsuz iddia yoktur: **Y yalnızca bu kamu araştırmasında doğrulanamadı** demektir. Teknik ekipman kataloglarının bulguları gemi tipine otomatik aktarılmamalıdır.

**Teslim durumu:** Araştırma tamamlandı; özel erişim veya engel aşma ihtiyacı oluşmadı. Bu dosya ana teslim paketine dahil edilecek çalışma raporudur; kendi başına canlı uygulama değişikliği yapmaz.
