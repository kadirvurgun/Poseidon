# Poseidon — Bayrak ve Gemi Tipi Alanları: Mevzuat ve Standart Kanıt Raporu

Araştırma / erişim tarihi: **29 Ekim 2026 (UTC)**. Durum: ürün analizi için öneri; hukuk görüşü, gemi sertifikasyonu, tamamlanmış mevzuat denetimi veya üretime yüklenmiş kod kataloğu değildir. Kapsam: gemiler ve römorkörler, TR/EN arayüz, self-hosted veri modeli. Kaynaklar birincil kurum yayınlarıdır. Dış katalogların tamamı kopyalanmamıştır.

## 1. Öncelikli sonuç

**Bir adet “Bayrak” ve bir adet “Gemi Tipi” serbest metni yeterli değildir; ancak her şeyi tek evrensel kod listesine zorlamak da yanlıştır.** Poseidon'un kontrollü ürün sınıfları; ulusal sicil cinsi, AIS yayın kodu, uluslararası raporlama kodu ve mevzuata özgü gemi sınıfından ayrılmalıdır. Bayrak idaresi ile ülke kodu, sicil ve sicil limanı aynı kavram değildir. Standartlaştırma kararı aşağıdaki ayrımları korumalıdır.

Araştırmada kritik güncellik bulguları:

- ITU kaydı **M.1371-6 (02/2026)** sürümünü yürürlükte, M.1371-5 (02/2014) sürümünü yürürlükten kaldırılmış/superseded olarak gösterir. Eski AIS tablosu güncel diye sunulmamalı; eski cihaz/veri uyumluluğu sürümle yönetilmelidir. [S4]
- UAB'nin mevcut sayfasından indirilen sicil cinsleri PDF'inin dosya adı **08-2026** sürümünü işaret eder. Belgenin 24. sayfasında **4304 Açık Deniz Römorkörü**, **4305 Kılavuz Römorkörleri** vardır. Bunlar ürünün tüm römorkör mimarilerini kapsayan katalog değildir. [S9]
- IMO'nun FAL 50 toplantısında (Mart 2026) güncellenmiş Compendium sürümü onaylandığını açıklayan sayfası vardır. Raporlama tasarımı eski referans modeline sabitlenmemelidir. [S7]
- IMO gemi numarası hâlen yedi basamak olarak tarif edilmektedir. Gelecekte sekiz basamağa genişletme ifadesi bugünden sekiz basamak kabul edilmesine kanıt değildir. [S12, S13]

## 2. Hukuki yükümlülük — taksonomi — ürün kararı ayrımı

| Katman | Ne sağlar? | Ne sağlamaz? | Poseidon kararı |
|---|---|---|---|
| Bayrak devleti ve ulusal sicil hukuku | Bayrak çekme ve kayıt ilişkisi; yetkili idare/kayıt delili | Her ülke kodunun otomatik geçerli gemi bayrağı olduğu sonucu | İdare kaydı ve belge doğrulaması; tarihçeli bayrak ataması |
| SOLAS, MARPOL, ISM ve ulusal uygulama | Kendi kapsamındaki gemiler için yükümlülükler | İki açılır listeyle hukuki uygunluk | Ayrı, gerekçeli uygulanabilirlik değerlendirmesi |
| ISO 3166 | Ülke/bölge kodlarının temsilini standartlaştırır | Gemi sicili yetkisi veya bayrak idaresi listesi | Ülke referansı ve dışa aktarım eşleştirmesi |
| ITU-R M.1371 | AIS mesajındaki gemi/yük tipi alanı | Sertifikadaki hukuki cins veya komple filo sınıflandırması | Ham AIS kodu + standart sürümü + gözlem zamanı |
| UNECE Rec.28 / IMO Compendium / EMSWe | Ticaret/liman veri alışverişinde ortak anlam ve kodlar | Her ülkede her gemi için aynı form zorunluluğu | Hedef sisteme özgü sürümlü dışa aktarım profili |
| UAB sicil cins tanımları | Türkiye kayıt işlerinde kullanılan cins tanımları | Evrensel EN operasyonel katalog veya AIS eşdeğerliği | Ayrı ulusal kod alanı; belge ve kaynak sürümü |
| Poseidon kontrollü ürün kataloğu | Filtreleme, raporlar ve kullanıcı deneyimi | Hukuki izin, sınıf sertifikası veya yasal uygunluk kararı | Açıkça “ürün standardı”, yetkili onayıyla yayın |

## 3. Bayrak: veri modelinin zorunlu ayrımları

IMO'nun açıklaması, UNCLOS madde 91 altında devletlerin gemi milliyeti, kendi topraklarındaki kayıt ve bayrak hakkına ilişkin koşulları belirlediğini; madde 94 altında bayrak devletinin idari/teknik/sosyal yetki ve denetim uygulamasını vurgular. Aynı açıklama, 1986 Kayıt Koşulları Sözleşmesinin yürürlüğe girmediğini belirtir. Bu yüzden “uluslararası sicil standardı her ülkede aynen zorunlu” denmemelidir. [S1]

Önerilen sözlük (alanların zorunluluğu ürün/iş akışı kararıdır, doğrudan yasal zorunluluk iddiası değildir):

| Anahtar | TR / EN | Anlam ve doğrulama |
|---|---|---|
| `flag_administration_id` | Bayrak idaresi / Flag administration | Kontrollü, sürümlü idare kaydına FK. Geminin geçerli belgesindeki idare esas alınır. |
| `flag_country_iso2` | Bayrak ülke/bölge kodu / Flag country or territory code | İdare kaydının varsa ISO 3166-1 alpha-2 ilişkisi; kimlik anahtarı yerine kullanılması zorunlu değildir. |
| `registry_id` | Gemi sicili / Ship registry | Kayıt rejimi/kurumu; aynı ülke altında birden çok sicile izin verir. |
| `registry_number` | Sicil numarası / Registry number | İlgili sicilin verdiği metinsel kimlik; IMO numarası değildir. |
| `port_of_registry_id` | Sicil limanı / Port of registry | Yetkili kayıttaki liman; mevcut liman veya ana operasyon üssü değildir. Yer kodu varsa ayrıca eşleştirilir. |
| `registry_status` | Kayıt durumu / Registration status | Ürün kontrollü durumu: doğrulanmış, belge bekliyor, askıda vb.; resmi statünün ham metni ayrıca korunur. |
| `flag_valid_from`, `flag_valid_to` | Geçerlilik başlangıç/bitiş / Valid from/to | Bayrak değişimini üstüne yazmak yerine dönemsel kayıt. |
| `evidence_document_id`, `verified_at`, `verified_by` | Belge / doğrulayan / zaman | Sertifika ve idare kaydı ile izlenebilirlik. |

ISO'nun kendisi, ülke isimlerinin UN kaynaklarından geldiğini; standardın kodları temsil ettiğini ve güncel kodların OBP'de bulunduğunu açıklar. ISO kodunun bulunması gemi bayrağı için yetkilendirme kanıtı değildir; bu ayrım bu raporun veri modelleme çıkarımıdır. [S2] “Unknown”, “not provided”, “unverified”, “not applicable” gibi ürün durumlarına uydurma ISO kodu atamayın. Ayrı kalite/durum alanında tutun. Ülke bayrağı emojisi gösterge olabilir ama erişilebilir etiketin veya resmi kaydın yerine geçmez.

Bareboat/paralel kayıt gibi durumlar için kayıt türü ve dönem ilişkisi eklenebilir; **eşzamanlı birden fazla etkin bayrak hakkı varmış gibi modellemeyin**. Hangi idarenin etkin bayrak olduğunu ve diğer kaydın hukuki niteliğini uzman doğrulasın. Sahip/işletmeci ülkesi bayraktan türetilmez.

## 4. Gemi tipi: beş ayrı eksen

1. **Ürün ana sınıfı** (`vessel_category_id`): ticari operasyon raporları için sabit ürün kimliği; örneğin yük, tanker, yolcu, römorkör, açık deniz destek, hizmet, balıkçılık. Bu örnekler eksiksiz veya onaylanmış seed değildir.
2. **Ürün alt tipi** (`vessel_subtype_id`): ana sınıfa bağlı, tanımı açık kontrollü değer. Bir geminin çok amaçlı niteliği ayrıca rollerle temsil edilir.
3. **Ulusal sicil cinsi** (`registry_ship_type_code`, `registry_type_scheme`, `registry_type_version`): sertifikadaki/ulusal sicildeki kod. Türk kaydı için UAB kataloğu; EN karşılıklar kuruma ait resmi çeviri olarak değil onay bekleyen ürün çevirisi olarak işaretlenir.
4. **AIS tipi** (`ais_ship_type_code`, `ais_standard_version`, `ais_received_at`): yayınlanan 8 bit alanı ve ham gözlem. AIS doğruluğu veya hukuki cins için tek başına otorite değildir. Aktif mevzuat sınıfını AIS mesajı güncellemesiyle değiştirmeyin.
5. **Mevzuata özgü sınıf** (`regulatory_classifications[]`): enstrüman, sürüm, madde, sınıf, geçerlilik, karar veren ve kanıtla birlikte çoklu kayıt. SOLAS'taki “cargo ship” gibi üst tanım günlük ticari yük kategorisiyle birebir olmak zorunda değildir.

ITU 2026 kaynağında AIS **52** römorkörleri; **31** yedekleme ve **32** uzunluğu/genişliği belirli eşikleri aşan yedekleme durumunu temsil eder. Dolayısıyla 31/32/52'yi üç kalıcı römorkör gövde alt tipi saymak yanlıştır. Güncel tabloda 38/39 ve bazı yolcu kodlarının anlamlarının eski yaygın tablolardan farklılaşması sürüm ihtiyacını ayrıca gösterir; bütün tablo bu rapora kopyalanmamıştır. [S3, S4]

UNECE Rec.28 ticari taşıma aracı türlerinin ortak kod listesidir; resmi indeks 2018 revizyon 4.2 listesini gösterir. EMSA'nın güncel EMSWe veritabanı rehberi hem farklı detay seviyelerindeki tipleri hem yedekli/yedeksiz çekici ayrımlarını içerir. Bunları AIS sayılarıyla sayı benzerliğine göre birleştirmeyin. Hedef entegrasyonun kabul ettiği profil/sürüm ayrı doğrulanır. [S5, S6]

### Römorkör için ayrı operasyonel/teknik boyutlar

Önerilen bağımsız alanlar:
- `tug_operational_roles[]`: liman yardımı, açık deniz çekisi, eskort, kurtarma vb.; çoklu ve tarihçeli rol, yetki belgesi yerine geçmez.
- `tug_drive_configuration_id`: ASD, tractor, conventional gibi sistem/mimari ayrımları için uzman onaylı ürün kataloğu; pazarlama isimleri ve marka tabanlı terimler denetlenmelidir.
- `propulsion_technology_id`: konvansiyonel pervane, azimut, cycloidal vb.; mimariyle karıştırılmamalı.
- `energy_system_id`: dizel, dizel-elektrik, hibrit, batarya-elektrik vb.; propulsion ve görevden ayrı.
- `bollard_pull_value`, `bollard_pull_unit`, `test_date`, `certificate_id`: değer/birim/test kanıtı; bilinmiyor değerini sıfır yapmayın.
- `escort_rating`, `firefighting_class_notation`, `class_society_id`: sertifikalı yetenek/notasyon ayrı doğrulanır; sadece bir ekipmanın varlığından sertifika türetilmez.

Bunlar hukuki sınıf listesi değil, önerilen ürün alanlarıdır. UAB'nin 4304/4305 ayrımı ekipman/çeki sertifikası ve kullanım bağlamı içerir; bir gemiyi sadece kullanıcının “ocean tug” demesiyle 4304'e atamayın. Aynı belgede 4202 açık deniz faaliyetleri destek gemisi için sertifikalı çeki kabiliyetinden söz edilmesi, “çekebilir = römorkör sicil sınıfı” kestirmesinin yanlışlığını gösterir. [S9]

## 5. Uygulanabilirlik matrisi: hiçbir eşik tek başına yeterli değildir

| Konu | Doğrulanmış kapsam örneği | Alan tasarımına sonuç |
|---|---|---|
| SOLAS genel / bölüm V | IMO açıklaması bölüm V'nin genel olarak tüm gemiler/tüm seferler için operasyonel hükümler içerdiğini, sözleşmenin genel kapsamının daha sınırlı olduğunu ayırır. [S10] | “500 GT altı, bütün SOLAS dışı” kuralı kurmayın. Bölüm/madde bazlı değerlendirme. |
| AIS taşıma | IMO özeti: uluslararası seferde 300 GT ve üstü gemiler; uluslararası olmayan seferde 500 GT ve üstü yük gemileri; büyüklüğünden bağımsız yolcu gemileri. İstisna/ulusal uygulama ayrıca incelenmeli. [S11] | GT, sefer ve mevzuat gemi sınıfı gerekir; tüm römorkörlere otomatik zorunlu denmez. |
| ISM / SOLAS IX | Transport Canada açıklaması uluslararası seferde yolcu gemilerini ve 500 GT+ belirtilen yük/MODU gruplarını ayırır. Ulusal uygulama daha geniş olabilir. [S14] | Bayrak ve faaliyet ülkesi, sefer, sınıf, GT ve ulusal düzenleme sürümü gerekir. |
| MARPOL VI / EEXI / CII | IMO genel Annex VI kapsamını, 400 GT temelli bölüm 4/sörvey ve 5.000 GT CII eşiğini açıklar; gemi türleri ve salt bayrak devleti sularındaki sefer istisnası önemlidir. [S15] | “5.000 GT+ her römorköre CII” veya “400 GT altı MARPOL yok” sonucu çıkarılamaz. İlgili tanımlı sınıf ve madde teyidi şarttır. |
| Türkiye sicili | Resmî Gazete 12.05.2023/32188 Gemi Sicil Yönetmeliği UAB mevzuat indeksinde yer alır. [S8] | Sicil rejimi ve güncel değişiklikler hukuk uzmanıyla kontrol; taslak 2021 metni yürürlükte mevzuat yerine kullanılmaz. |

Uygulanabilirlik kaydı en az `instrument`, `edition`, `article`, `flag`, `voyage_scope`, `operating_area`, `regulatory_ship_type`, `gross_tonnage`, `tonnage_basis`, `build_or_conversion_date`, `decision_status`, `reason`, `evidence`, `reviewed_by`, `reviewed_at` içermelidir. Değerler `applies / does_not_apply / unknown / pending_expert_review`; null bilgi, “uygulanmaz” değildir. GT, DWT ve deplasman ayrı niceliklerdir. Bir geminin hukuki uygunluğu sadece sınıflandırmayla ispatlanmaz.

## 6. IMO numarası: mevcut yedi haneli doğrulamayı bozmadan geleceğe hazırlık

IMO'nun güncel gemi numarası sayfasından kısa alıntı: **“Future numbers may be extended to eight digits when the need for more numbers arises.”** Aynı bölüm mevcut biçimi IMO ön eki + yedi basamak olarak açıklar. Sayfa Aralık 2025 A.1215(34) ile gemi ve şirket/sahip şemalarının entegre edildiğini belirtir. Bu entegrasyon, gemi kimliği ile şirket kimliğini aynı alana koyma gerekçesi değildir. [S12]

Bağlantılı FAQ'nin rakam uzatma içeriği 2022/2023 etki araştırması ve alternatif öneriler bağlamındadır; güncel sekiz basamak dağıtım başlangıcı kanıtı değildir. **Bu araştırmada yürürlüğe girmiş sekiz basamak dağıtım tarihi doğrulanmamıştır.** [S13]

Öneri: mevcut gemi numarası için yedi hane ve checksum doğrulamasını koruyun; veri saklamayı string, validator'ı şema/sürüm bazlı tasarlayın. Gelecek uzatmayı resmi teknik ayrıntı, checksum ve geçiş tarihi doğrulandıktan sonra kontrollü sürümle etkinleştirin. Eksik veya kapsam dışı IMO numarası için sahte numara üretmeyin; `not_assigned / not_applicable / unknown / pending_verification` durumları ayrı olsun. IMO numarası doğru biçimde diye gerçek gemiye atanmış olduğu sonucuna varılmaz. Reflag sırasında gemi IMO kimliği korunur; MMSI ve sicil kayıtları aynı sabit kimlik varsayımına alınmaz.

## 7. Kod kataloğu ve self-hosted yönetişim tasarımı

Önerilen her katalog girdisi: `id` (değişmez ürün kimliği), `namespace`, `source_code`, `source_version`, `parent_id`, `label_tr`, `label_en`, `definition_tr`, `definition_en`, `status`, `valid_from`, `valid_to`, `source_url`, `accessed_at`, `license_status`, `approved_by`, `approved_at`. Çeviri durumu da saklanmalı. Ad değişikliği kimliği değiştirmemeli.

Çapraz eşleştirme tablosu: kaynak/hedef şema+sürüm+kod; `exact / broader / narrower / conditional / no_mapping`; koşul, gerekçe ve insan onayı. Bir dış kod birden fazla ürün sınıfını kapsıyorsa birebir eşleşme uydurulmaz. Örneğin AIS 52 → ürün TUG üst sınıfı destekleyebilir, fakat bundan UAB 4304 veya 4305 seçilemez. Bunları belirlemek için belge gerekir.

Self-hosted dağıtım: onaylanmış katalog paketi sürümü, checksum, release notes, lisans kaydı ve rollback; offline ortamda local cache; bir tenant'ın özel değeri resmi namespace'e eklenmez. `tenant:*` uzantıları merkezi tanımdan ayrılır. Silmek yerine pasifleştirme; geçmiş raporlar eski sürümü tekrar üretebilmeli. API ve UI aynı backend doğrulama kurallarını kullanmalı.

Migrasyon: ham `flag` / `ship_type` değerlerini sakla → normalize edilmiş adaylar oluştur → yalnız kesin eşleşmeleri otomatik ata → belirsizleri inceleme kuyruğuna al → onayla → önce/sonra sayıları ve istisna raporunu üret. Zorunlu olmayan hedef alana bilinmeyeni “Other” diye doldurmak veri kalitesi kaybıdır. “Other” bilinen fakat katalogda bulunmayan sınıf, “Unknown” bilinmeyen sınıf olmalıdır. Geriye dönük silme veya toplu yanlış dönüşüm yapılmamalı.

## 8. Açık kararlar ve çıkış kriterleri

1. Hedef filonun bayrakları, sicil rejimleri ve faaliyet ülkeleri; TR ulusal ve uluslararası sefer kapsamı.
2. Ana/alt ürün kategorileri için denizcilik uzmanı ve ürün sahibinin onayı; EN çeviri onayı.
3. Bayrak idaresi listesinin yetkili kaynağı, tarihsel bayraklar ve özel idari bölgeler için yönetim kararı. ISO listesini bütünüyle “geçerli bayraklar” diye yüklememek.
4. UAB/ITU/UNECE/ISO/EMSWe içerikleri için kullanım/yeniden dağıtım izin ve lisans incelemesi. Halka açık okunabilirlik toplu ticari yeniden dağıtım izni değildir. Bu rapor tam katalog veya standart metin paketi dağıtmaz.
5. UAB 08-2026 dosya adının dayandığı idari onay tarihi, sonraki değişiklikler ve güncel sicil yönetmeliği konsolidasyonunun uzman teyidi. Resmî Gazete PDF erişildi ancak araçtan metin/screenshot çözülemedi; maddeler hakkında teyitsiz ayrıntı üretilmedi.
6. Mevzuat matrisi için bayrak bazında hukuk/klas onayı; burada kapsam örnekleri tam liste değildir. MLC, ISPS, Load Lines, tonaj, ulusal teknik kurallar ve faaliyet izinleri ayrıca proje kapsamına göre incelenmelidir.
7. Üretim onayı ancak katalog sahibi, sürüm/lisans kaydı, testler, belirsiz migrasyonların çözümü ve rollback kanıtıyla verilmeli. Bu rapor üretim seed'inin bittiğini iddia etmez.

## 9. Kaynak sicili — tüm erişimler 29.10.2026

**S1 — IMO, Registration of ships and fraudulent registration matters.** UNCLOS 91/94 çerçevesi, ulusal kayıt ve 1986 sözleşmesinin durumu. https://www.imo.org/en/ourwork/legal/pages/registration-of-ships.aspx

**S2 — ISO, ISO 3166 Country Codes.** Kapsam, alpha-2 ve güncelleme/OBP modeli. https://www.iso.org/iso-3166-country-codes.html

**S3 — ITU-R M.1371-6, 02/2026, resmi metin.** AIS gemi/yük türü tablosu; özellikle 31/32/52. https://www.itu.int/epublications/fr/publication/recommendation-itu-r-m-1371-6-02-2026-technical-characteristics-for-vhf-automatic-identification-system-using-time-division-multiple-access-in-the-maritime-mobile-se/en ; PDF: https://www.itu.int/dms_pubrec/itu-r/rec/m/R-REC-M.1371-6-202602-I%21%21PDF-E.pdf

**S4 — ITU Recommendation register M.1371.** M.1371-6 yürürlükte, -5 superseded. https://www.itu.int/rec/r-rec-m.1371/_page.print

**S5 — UNECE, Code List Recommendations / Rec.28.** Rev.3 (2010) temel metin ve Rev.4.2 (2018) kod listesi indeks kaydı. https://unece.org/code-list-recommendations

**S6 — EMSA, EMSWe databases System Interface Guide.** EMSWe gemi tipi referansları; bu entegrasyona özgü kapsam. https://emswe-db-sig.emsa.europa.eu/ ; genel MIG: https://www.emsa.europa.eu/emswe-mig/index.htm

**S7 — IMO Compendium.** Mart 2026 FAL 50 sürümü açıklaması ve güncel modele bağlantı. https://www.imo.org/en/ourwork/facilitation/pages/imocompendium.aspx ; model: https://imocompendium.imo.org/public/IMO-Compendium/Current/index.htm

**S8 — UAB mevzuat indeksi / Resmî Gazete.** Gemi Sicil Yönetmeliği 12.05.2023 / 32188. https://denizcilik.uab.gov.tr/mevzuat/denizcilik-mevzuati/yonetmelik/ ; resmi PDF: https://www.resmigazete.gov.tr/eskiler/2023/05/20230512-18.pdf

**S9 — UAB, Gemi Sicili İçin Gemi Cinsleri Tanımlamaları.** Mevcut UAB indirme bağlantısı 08-2026 dosyası; 32 sayfa. Bölüm 43, s.24 (PDF sıfır-indeks 23); 4202 s.23. https://denizcilik.uab.gov.tr/media/denizcilik/dsfhl5xt/gemi-sicili-icin-gemi-cinsleri-tanimlamalari-08-2026.pdf ; kaynak giriş sayfası: https://denizcilik.uab.gov.tr/hizli-menu/gemi-denetim-modulu/gemi-cins-tanimlamalari/

**S10 — IMO, SOLAS overview.** Bölüm IV/V kapsamı ve farklı bölüm yaklaşımı. https://www.imo.org/en/about/conventions/pages/international-convention-for-the-safety-of-life-at-sea-%28solas%29%2C-1974.aspx

**S11 — IMO, AIS transponders.** V/19 AIS taşıma özet eşikleri. https://www.imo.org/en/ourwork/safety/pages/ais.aspx

**S12 — IMO, Identification Number Scheme.** Güncel yedi basamak, koşullu gelecek uzatma, A.1215(34), ayrı gemi/şirket bağlamı. https://www.imo.org/en/ourwork/iiis/pages/imo-identification-number-schemes.aspx

**S13 — IMO-hosted Ship Numbering FAQ.** Eski teklif ve 2022–2023 araştırma bağlamı; mevcut sekiz hane dağıtım kanıtı değildir. https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/IMO%20Ship%20Number%20%26%20Extension%20FAQs.pdf

**S14 — Transport Canada, International Safety Management (ISM) Code.** SOLAS IX uluslararası kapsam özeti, ulusal otorite açıklaması. https://tc.canada.ca/en/marine-transportation/marine-safety/international-safety-management-ism-code

**S15 — IMO, EEXI and CII FAQ.** Annex VI kapsamı, GT eşikleri, sefer ve tip bağlamı. https://www.imo.org/en/mediacentre/hottopics/pages/eexi-cii-faq.aspx

### Araştırma sınırlamaları

UAB'nin eski `/tr/gemi-sicil` adresi 404 döndü; güncel navigasyondan resmi sayfa ve dosya bulundu. UAB 08-2026 PDF metni web aracıyla okunabildi, screenshot cache miss verdi. Resmî Gazete sicil PDF'i 25 sayfa olarak erişildi; metni yalnız başlık düzeyinde çözüldü ve screenshot başarısız oldu. Bu teknik sınırlamalar sebebiyle yönetmeliğin tek tek maddeleri hakkında sonuç üretilmedi. Engellenen hiçbir dosya/izin eskalasyonu veya dış yazma işlemi yoktur. Tüm kataloglar ve gemiye özgü hukuki kapsam için nihai uzman/ürün onayı açık tutulmuştur.
