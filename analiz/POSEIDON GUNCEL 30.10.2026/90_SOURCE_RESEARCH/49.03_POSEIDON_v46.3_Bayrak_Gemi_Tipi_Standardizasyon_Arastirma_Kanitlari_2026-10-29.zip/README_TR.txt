49.03 Bayrak ve gemi tipi araştırma kanıtları
29.10.2026 — Analiz ve öneri. Üretim kodu veya onaylı katalog değildir.

Özgün teknik ZIP ve araştırmalar değiştirilmeden korunur. Raw regulatory_research.md sicil/kanıt statüsünü karıştıran tarihsel ifadeyi içerir; reviews/reconciliation_contract.json ve content_review.json bu ifadeyi düzeltir. 49.01 ve49.02 nihai tasarımda ayrı registry_status ve verification_status vardır. G01–G08 ve eşleme yönleri uzlaştırılmıştır.

12 sentetik model testi küçük formatVersion1 öneri örneği içindir; zenginleştirilmiş son sözlüğün, gerçek kod listesinin, API/DB/UX geçişinin ya da mevzuat uygunluğunun testi değildir. 14.02 kaynak kimliği doğrulandı;518 satır kaynak boşluğu sınıf sayısı değildir, üretim lookup kapanışı0.

Ürün kaynakları151 dosyada dd504631b8df6c3061953444295353ae53041afc ile aynıdır. Proposal-only patch uygulanmadı. Tam katalog, lisans, uzman onayı, uyumluluk ve kullanıcı kabul kapıları açıktır. UAB PDF araştırmacı metin okuması ile desteklenir; bağımsız reviewer parser hatası nedeniyle o PDF içeriğini yeniden doğrulamadı.

MANIFEST_SHA256.json bu arşivin kendisi dışındaki tüm girdileri doğrular. İlgili düzenlenebilir tasarım belgeleri ana klasörde49.01/49.02 olarak yer alır.
